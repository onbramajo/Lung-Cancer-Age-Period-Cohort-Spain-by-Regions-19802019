

apc.AvgF1 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF2 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF3 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF4 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF5 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF6 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF7 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF8 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.AvgF9 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF10 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1989,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF11 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1990,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF12 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1991,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF13 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1992,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF14 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1993,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF15 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1994,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF16 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1995,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.AvgF17 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1996,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF18 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1997,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF19 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1998,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF20 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 1999,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF21 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2000,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF22 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2001,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF23 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2002,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF24 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2003,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.AvgF25 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2004,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF26 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2005,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF27 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2006,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF28 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2007,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF29 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2008,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF30 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2009,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF31 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2010,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AvgF32 <- apc.fit( subset( AvgF ),
                      parm = "APC",
                      ref.p = 2011,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


apc.AvgF33 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF34 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF35 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF36 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF37 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF38 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF39 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AvgF40 <- apc.fit( subset( AvgF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


AvgSmoothRate <- rbind(apc.AvgF1[["Age"]],
                       apc.AvgF2[["Age"]],
                       apc.AvgF3[["Age"]],
                       apc.AvgF4[["Age"]],
                       apc.AvgF5[["Age"]],
                       apc.AvgF6[["Age"]],
                       apc.AvgF7[["Age"]],
                       apc.AvgF8[["Age"]],
                       apc.AvgF9[["Age"]],
                       apc.AvgF10[["Age"]],
                       apc.AvgF11[["Age"]],
                       apc.AvgF12[["Age"]],
                       apc.AvgF13[["Age"]],
                       apc.AvgF14[["Age"]],
                       apc.AvgF15[["Age"]],
                       apc.AvgF16[["Age"]],
                       apc.AvgF17[["Age"]],
                       apc.AvgF18[["Age"]],
                       apc.AvgF19[["Age"]],
                       apc.AvgF20[["Age"]],
                       apc.AvgF21[["Age"]],
                       apc.AvgF22[["Age"]],
                       apc.AvgF23[["Age"]],
                       apc.AvgF24[["Age"]],
                       apc.AvgF25[["Age"]],
                       apc.AvgF26[["Age"]],
                       apc.AvgF27[["Age"]],
                       apc.AvgF28[["Age"]],
                       apc.AvgF29[["Age"]],
                       apc.AvgF30[["Age"]],
                       apc.AvgF31[["Age"]],
                       apc.AvgF32[["Age"]],
                       apc.AvgF33[["Age"]],
                       apc.AvgF34[["Age"]],
                       apc.AvgF35[["Age"]],
                       apc.AvgF36[["Age"]],
                       apc.AvgF37[["Age"]],
                       apc.AvgF38[["Age"]],
                       apc.AvgF39[["Age"]],
                       apc.AvgF40[["Age"]])





apc.AndF1 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF2 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF3 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF4 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF5 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF6 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF7 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF8 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.AndF9 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF10 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF11 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF12 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF13 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF14 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF15 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF16 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.AndF17 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF18 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF19 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF20 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF21 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF22 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF23 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF24 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.AndF25 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF26 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF27 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF28 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF29 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF30 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF31 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF32 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.AndF33 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF34 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF35 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF36 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF37 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF38 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF39 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AndF40 <- apc.fit( subset( AndF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


AndSmoothRate <- rbind(apc.AndF1[["Age"]],
                       apc.AndF2[["Age"]],
                       apc.AndF3[["Age"]],
                       apc.AndF4[["Age"]],
                       apc.AndF5[["Age"]],
                       apc.AndF6[["Age"]],
                       apc.AndF7[["Age"]],
                       apc.AndF8[["Age"]],
                       apc.AndF9[["Age"]],
                       apc.AndF10[["Age"]],
                       apc.AndF11[["Age"]],
                       apc.AndF12[["Age"]],
                       apc.AndF13[["Age"]],
                       apc.AndF14[["Age"]],
                       apc.AndF15[["Age"]],
                       apc.AndF16[["Age"]],
                       apc.AndF17[["Age"]],
                       apc.AndF18[["Age"]],
                       apc.AndF19[["Age"]],
                       apc.AndF20[["Age"]],
                       apc.AndF21[["Age"]],
                       apc.AndF22[["Age"]],
                       apc.AndF23[["Age"]],
                       apc.AndF24[["Age"]],
                       apc.AndF25[["Age"]],
                       apc.AndF26[["Age"]],
                       apc.AndF27[["Age"]],
                       apc.AndF28[["Age"]],
                       apc.AndF29[["Age"]],
                       apc.AndF30[["Age"]],
                       apc.AndF31[["Age"]],
                       apc.AndF32[["Age"]],
                       apc.AndF33[["Age"]],
                       apc.AndF34[["Age"]],
                       apc.AndF35[["Age"]],
                       apc.AndF36[["Age"]],
                       apc.AndF37[["Age"]],
                       apc.AndF38[["Age"]],
                       apc.AndF39[["Age"]],
                       apc.AndF40[["Age"]])




apc.AraF1 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF2 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF3 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF4 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF5 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF6 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF7 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF8 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.AraF9 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF10 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF11 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF12 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF13 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF14 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF15 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF16 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.AraF17 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF18 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF19 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF20 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF21 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF22 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF23 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF24 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.AraF25 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF26 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF27 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF28 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF29 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF30 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF31 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF32 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.AraF33 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF34 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF35 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF36 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF37 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF38 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF39 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AraF40 <- apc.fit( subset( AraF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


AraSmoothRate <- rbind(apc.AraF1[["Age"]],
                       apc.AraF2[["Age"]],
                       apc.AraF3[["Age"]],
                       apc.AraF4[["Age"]],
                       apc.AraF5[["Age"]],
                       apc.AraF6[["Age"]],
                       apc.AraF7[["Age"]],
                       apc.AraF8[["Age"]],
                       apc.AraF9[["Age"]],
                       apc.AraF10[["Age"]],
                       apc.AraF11[["Age"]],
                       apc.AraF12[["Age"]],
                       apc.AraF13[["Age"]],
                       apc.AraF14[["Age"]],
                       apc.AraF15[["Age"]],
                       apc.AraF16[["Age"]],
                       apc.AraF17[["Age"]],
                       apc.AraF18[["Age"]],
                       apc.AraF19[["Age"]],
                       apc.AraF20[["Age"]],
                       apc.AraF21[["Age"]],
                       apc.AraF22[["Age"]],
                       apc.AraF23[["Age"]],
                       apc.AraF24[["Age"]],
                       apc.AraF25[["Age"]],
                       apc.AraF26[["Age"]],
                       apc.AraF27[["Age"]],
                       apc.AraF28[["Age"]],
                       apc.AraF29[["Age"]],
                       apc.AraF30[["Age"]],
                       apc.AraF31[["Age"]],
                       apc.AraF32[["Age"]],
                       apc.AraF33[["Age"]],
                       apc.AraF34[["Age"]],
                       apc.AraF35[["Age"]],
                       apc.AraF36[["Age"]],
                       apc.AraF37[["Age"]],
                       apc.AraF38[["Age"]],
                       apc.AraF39[["Age"]],
                       apc.AraF40[["Age"]])




apc.AstF1 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF2 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF3 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF4 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF5 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF6 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF7 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF8 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.AstF9 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF10 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF11 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF12 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF13 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF14 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF15 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF16 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.AstF17 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF18 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF19 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF20 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF21 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF22 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF23 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF24 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.AstF25 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF26 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF27 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF28 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF29 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF30 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF31 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF32 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.AstF33 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF34 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF35 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF36 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF37 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF38 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF39 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.AstF40 <- apc.fit( subset( AstF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


AstSmoothRate <- rbind(apc.AstF1[["Age"]],
                       apc.AstF2[["Age"]],
                       apc.AstF3[["Age"]],
                       apc.AstF4[["Age"]],
                       apc.AstF5[["Age"]],
                       apc.AstF6[["Age"]],
                       apc.AstF7[["Age"]],
                       apc.AstF8[["Age"]],
                       apc.AstF9[["Age"]],
                       apc.AstF10[["Age"]],
                       apc.AstF11[["Age"]],
                       apc.AstF12[["Age"]],
                       apc.AstF13[["Age"]],
                       apc.AstF14[["Age"]],
                       apc.AstF15[["Age"]],
                       apc.AstF16[["Age"]],
                       apc.AstF17[["Age"]],
                       apc.AstF18[["Age"]],
                       apc.AstF19[["Age"]],
                       apc.AstF20[["Age"]],
                       apc.AstF21[["Age"]],
                       apc.AstF22[["Age"]],
                       apc.AstF23[["Age"]],
                       apc.AstF24[["Age"]],
                       apc.AstF25[["Age"]],
                       apc.AstF26[["Age"]],
                       apc.AstF27[["Age"]],
                       apc.AstF28[["Age"]],
                       apc.AstF29[["Age"]],
                       apc.AstF30[["Age"]],
                       apc.AstF31[["Age"]],
                       apc.AstF32[["Age"]],
                       apc.AstF33[["Age"]],
                       apc.AstF34[["Age"]],
                       apc.AstF35[["Age"]],
                       apc.AstF36[["Age"]],
                       apc.AstF37[["Age"]],
                       apc.AstF38[["Age"]],
                       apc.AstF39[["Age"]],
                       apc.AstF40[["Age"]])




apc.BalF1 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF2 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF3 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF4 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF5 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF6 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF7 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF8 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.BalF9 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF10 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF11 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF12 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF13 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF14 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF15 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF16 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.BalF17 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF18 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF19 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF20 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF21 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF22 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF23 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF24 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.BalF25 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF26 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF27 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF28 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF29 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF30 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF31 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF32 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.BalF33 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF34 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF35 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF36 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF37 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF38 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF39 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.BalF40 <- apc.fit( subset( BalF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


BalSmoothRate <- rbind(apc.BalF1[["Age"]],
                       apc.BalF2[["Age"]],
                       apc.BalF3[["Age"]],
                       apc.BalF4[["Age"]],
                       apc.BalF5[["Age"]],
                       apc.BalF6[["Age"]],
                       apc.BalF7[["Age"]],
                       apc.BalF8[["Age"]],
                       apc.BalF9[["Age"]],
                       apc.BalF10[["Age"]],
                       apc.BalF11[["Age"]],
                       apc.BalF12[["Age"]],
                       apc.BalF13[["Age"]],
                       apc.BalF14[["Age"]],
                       apc.BalF15[["Age"]],
                       apc.BalF16[["Age"]],
                       apc.BalF17[["Age"]],
                       apc.BalF18[["Age"]],
                       apc.BalF19[["Age"]],
                       apc.BalF20[["Age"]],
                       apc.BalF21[["Age"]],
                       apc.BalF22[["Age"]],
                       apc.BalF23[["Age"]],
                       apc.BalF24[["Age"]],
                       apc.BalF25[["Age"]],
                       apc.BalF26[["Age"]],
                       apc.BalF27[["Age"]],
                       apc.BalF28[["Age"]],
                       apc.BalF29[["Age"]],
                       apc.BalF30[["Age"]],
                       apc.BalF31[["Age"]],
                       apc.BalF32[["Age"]],
                       apc.BalF33[["Age"]],
                       apc.BalF34[["Age"]],
                       apc.BalF35[["Age"]],
                       apc.BalF36[["Age"]],
                       apc.BalF37[["Age"]],
                       apc.BalF38[["Age"]],
                       apc.BalF39[["Age"]],
                       apc.BalF40[["Age"]])





apc.PVF1 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF2 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1981,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF3 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1982,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF4 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1983,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF5 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1984,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF6 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1985,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF7 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1986,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF8 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1987,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))



apc.PVF9 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1988,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF10 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1989,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF11 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1990,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF12 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1991,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF13 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1992,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF14 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1993,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF15 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1994,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF16 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1995,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.PVF17 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1996,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF18 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1997,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF19 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1998,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF20 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 1999,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF21 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2000,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF22 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2001,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF23 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2002,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF24 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2003,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.PVF25 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2004,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF26 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2005,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF27 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2006,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF28 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2007,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF29 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2008,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF30 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2009,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF31 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2010,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF32 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2011,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


apc.PVF33 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2012,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF34 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2013,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF35 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2014,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF36 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2015,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF37 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2016,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF38 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2017,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF39 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2018,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.PVF40 <- apc.fit( subset( PVF ),
                      parm = "APC",
                      ref.p = 2019,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


PVSmoothRate <- rbind(apc.PVF1[["Age"]],
                      apc.PVF2[["Age"]],
                      apc.PVF3[["Age"]],
                      apc.PVF4[["Age"]],
                      apc.PVF5[["Age"]],
                      apc.PVF6[["Age"]],
                      apc.PVF7[["Age"]],
                      apc.PVF8[["Age"]],
                      apc.PVF9[["Age"]],
                      apc.PVF10[["Age"]],
                      apc.PVF11[["Age"]],
                      apc.PVF12[["Age"]],
                      apc.PVF13[["Age"]],
                      apc.PVF14[["Age"]],
                      apc.PVF15[["Age"]],
                      apc.PVF16[["Age"]],
                      apc.PVF17[["Age"]],
                      apc.PVF18[["Age"]],
                      apc.PVF19[["Age"]],
                      apc.PVF20[["Age"]],
                      apc.PVF21[["Age"]],
                      apc.PVF22[["Age"]],
                      apc.PVF23[["Age"]],
                      apc.PVF24[["Age"]],
                      apc.PVF25[["Age"]],
                      apc.PVF26[["Age"]],
                      apc.PVF27[["Age"]],
                      apc.PVF28[["Age"]],
                      apc.PVF29[["Age"]],
                      apc.PVF30[["Age"]],
                      apc.PVF31[["Age"]],
                      apc.PVF32[["Age"]],
                      apc.PVF33[["Age"]],
                      apc.PVF34[["Age"]],
                      apc.PVF35[["Age"]],
                      apc.PVF36[["Age"]],
                      apc.PVF37[["Age"]],
                      apc.PVF38[["Age"]],
                      apc.PVF39[["Age"]],
                      apc.PVF40[["Age"]])




apc.CanF1 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF2 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF3 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF4 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF5 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF6 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF7 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF8 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.CanF9 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF10 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF11 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF12 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF13 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF14 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF15 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF16 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CanF17 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF18 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF19 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF20 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF21 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF22 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF23 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF24 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CanF25 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF26 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF27 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF28 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF29 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF30 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF31 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF32 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.CanF33 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF34 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF35 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF36 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF37 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF38 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF39 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CanF40 <- apc.fit( subset( CanF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


CanSmoothRate <- rbind(apc.CanF1[["Age"]],
                       apc.CanF2[["Age"]],
                       apc.CanF3[["Age"]],
                       apc.CanF4[["Age"]],
                       apc.CanF5[["Age"]],
                       apc.CanF6[["Age"]],
                       apc.CanF7[["Age"]],
                       apc.CanF8[["Age"]],
                       apc.CanF9[["Age"]],
                       apc.CanF10[["Age"]],
                       apc.CanF11[["Age"]],
                       apc.CanF12[["Age"]],
                       apc.CanF13[["Age"]],
                       apc.CanF14[["Age"]],
                       apc.CanF15[["Age"]],
                       apc.CanF16[["Age"]],
                       apc.CanF17[["Age"]],
                       apc.CanF18[["Age"]],
                       apc.CanF19[["Age"]],
                       apc.CanF20[["Age"]],
                       apc.CanF21[["Age"]],
                       apc.CanF22[["Age"]],
                       apc.CanF23[["Age"]],
                       apc.CanF24[["Age"]],
                       apc.CanF25[["Age"]],
                       apc.CanF26[["Age"]],
                       apc.CanF27[["Age"]],
                       apc.CanF28[["Age"]],
                       apc.CanF29[["Age"]],
                       apc.CanF30[["Age"]],
                       apc.CanF31[["Age"]],
                       apc.CanF32[["Age"]],
                       apc.CanF33[["Age"]],
                       apc.CanF34[["Age"]],
                       apc.CanF35[["Age"]],
                       apc.CanF36[["Age"]],
                       apc.CanF37[["Age"]],
                       apc.CanF38[["Age"]],
                       apc.CanF39[["Age"]],
                       apc.CanF40[["Age"]])




apc.CantF1 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1980,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF2 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1981,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF3 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1982,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF4 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1983,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF5 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1984,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF6 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1985,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF7 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1986,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF8 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1987,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CantF9 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1988,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF10 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1989,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF11 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1990,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF12 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1991,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF13 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1992,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF14 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1993,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF15 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1994,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF16 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1995,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))



apc.CantF17 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1996,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF18 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1997,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF19 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1998,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF20 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 1999,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF21 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2000,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF22 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2001,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF23 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2002,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF24 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2003,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))



apc.CantF25 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2004,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF26 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2005,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF27 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2006,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF28 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2007,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF29 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2008,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF30 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2009,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF31 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2010,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF32 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2011,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))


apc.CantF33 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2012,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF34 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2013,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF35 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2014,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF36 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2015,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF37 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2016,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF38 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2017,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF39 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2018,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))

apc.CantF40 <- apc.fit( subset( CantF ),
                        parm = "APC",
                        ref.p = 2019,
                        scale=100000,
                        npar=c(A=5, P=5, C=5))


CantSmoothRate <- rbind(apc.CantF1[["Age"]],
                        apc.CantF2[["Age"]],
                        apc.CantF3[["Age"]],
                        apc.CantF4[["Age"]],
                        apc.CantF5[["Age"]],
                        apc.CantF6[["Age"]],
                        apc.CantF7[["Age"]],
                        apc.CantF8[["Age"]],
                        apc.CantF9[["Age"]],
                        apc.CantF10[["Age"]],
                        apc.CantF11[["Age"]],
                        apc.CantF12[["Age"]],
                        apc.CantF13[["Age"]],
                        apc.CantF14[["Age"]],
                        apc.CantF15[["Age"]],
                        apc.CantF16[["Age"]],
                        apc.CantF17[["Age"]],
                        apc.CantF18[["Age"]],
                        apc.CantF19[["Age"]],
                        apc.CantF20[["Age"]],
                        apc.CantF21[["Age"]],
                        apc.CantF22[["Age"]],
                        apc.CantF23[["Age"]],
                        apc.CantF24[["Age"]],
                        apc.CantF25[["Age"]],
                        apc.CantF26[["Age"]],
                        apc.CantF27[["Age"]],
                        apc.CantF28[["Age"]],
                        apc.CantF29[["Age"]],
                        apc.CantF30[["Age"]],
                        apc.CantF31[["Age"]],
                        apc.CantF32[["Age"]],
                        apc.CantF33[["Age"]],
                        apc.CantF34[["Age"]],
                        apc.CantF35[["Age"]],
                        apc.CantF36[["Age"]],
                        apc.CantF37[["Age"]],
                        apc.CantF38[["Age"]],
                        apc.CantF39[["Age"]],
                        apc.CantF40[["Age"]])




apc.CyLF1 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF2 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF3 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF4 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF5 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF6 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF7 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF8 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.CyLF9 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF10 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF11 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF12 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF13 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF14 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF15 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF16 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CyLF17 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF18 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF19 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF20 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF21 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF22 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF23 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF24 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CyLF25 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF26 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF27 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF28 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF29 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF30 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF31 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF32 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.CyLF33 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF34 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF35 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF36 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF37 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF38 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF39 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CyLF40 <- apc.fit( subset( CyLF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


CyLSmoothRate <- rbind(apc.CyLF1[["Age"]],
                       apc.CyLF2[["Age"]],
                       apc.CyLF3[["Age"]],
                       apc.CyLF4[["Age"]],
                       apc.CyLF5[["Age"]],
                       apc.CyLF6[["Age"]],
                       apc.CyLF7[["Age"]],
                       apc.CyLF8[["Age"]],
                       apc.CyLF9[["Age"]],
                       apc.CyLF10[["Age"]],
                       apc.CyLF11[["Age"]],
                       apc.CyLF12[["Age"]],
                       apc.CyLF13[["Age"]],
                       apc.CyLF14[["Age"]],
                       apc.CyLF15[["Age"]],
                       apc.CyLF16[["Age"]],
                       apc.CyLF17[["Age"]],
                       apc.CyLF18[["Age"]],
                       apc.CyLF19[["Age"]],
                       apc.CyLF20[["Age"]],
                       apc.CyLF21[["Age"]],
                       apc.CyLF22[["Age"]],
                       apc.CyLF23[["Age"]],
                       apc.CyLF24[["Age"]],
                       apc.CyLF25[["Age"]],
                       apc.CyLF26[["Age"]],
                       apc.CyLF27[["Age"]],
                       apc.CyLF28[["Age"]],
                       apc.CyLF29[["Age"]],
                       apc.CyLF30[["Age"]],
                       apc.CyLF31[["Age"]],
                       apc.CyLF32[["Age"]],
                       apc.CyLF33[["Age"]],
                       apc.CyLF34[["Age"]],
                       apc.CyLF35[["Age"]],
                       apc.CyLF36[["Age"]],
                       apc.CyLF37[["Age"]],
                       apc.CyLF38[["Age"]],
                       apc.CyLF39[["Age"]],
                       apc.CyLF40[["Age"]])




apc.CLMF1 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF2 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF3 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF4 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF5 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF6 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF7 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF8 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.CLMF9 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF10 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF11 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF12 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF13 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF14 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF15 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF16 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CLMF17 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF18 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF19 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF20 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF21 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF22 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF23 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF24 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CLMF25 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF26 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF27 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF28 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF29 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF30 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF31 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF32 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.CLMF33 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF34 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF35 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF36 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF37 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF38 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF39 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CLMF40 <- apc.fit( subset( CLMF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


CLMSmoothRate <- rbind(apc.CLMF1[["Age"]],
                       apc.CLMF2[["Age"]],
                       apc.CLMF3[["Age"]],
                       apc.CLMF4[["Age"]],
                       apc.CLMF5[["Age"]],
                       apc.CLMF6[["Age"]],
                       apc.CLMF7[["Age"]],
                       apc.CLMF8[["Age"]],
                       apc.CLMF9[["Age"]],
                       apc.CLMF10[["Age"]],
                       apc.CLMF11[["Age"]],
                       apc.CLMF12[["Age"]],
                       apc.CLMF13[["Age"]],
                       apc.CLMF14[["Age"]],
                       apc.CLMF15[["Age"]],
                       apc.CLMF16[["Age"]],
                       apc.CLMF17[["Age"]],
                       apc.CLMF18[["Age"]],
                       apc.CLMF19[["Age"]],
                       apc.CLMF20[["Age"]],
                       apc.CLMF21[["Age"]],
                       apc.CLMF22[["Age"]],
                       apc.CLMF23[["Age"]],
                       apc.CLMF24[["Age"]],
                       apc.CLMF25[["Age"]],
                       apc.CLMF26[["Age"]],
                       apc.CLMF27[["Age"]],
                       apc.CLMF28[["Age"]],
                       apc.CLMF29[["Age"]],
                       apc.CLMF30[["Age"]],
                       apc.CLMF31[["Age"]],
                       apc.CLMF32[["Age"]],
                       apc.CLMF33[["Age"]],
                       apc.CLMF34[["Age"]],
                       apc.CLMF35[["Age"]],
                       apc.CLMF36[["Age"]],
                       apc.CLMF37[["Age"]],
                       apc.CLMF38[["Age"]],
                       apc.CLMF39[["Age"]],
                       apc.CLMF40[["Age"]])



apc.CatF1 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF2 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF3 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF4 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF5 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF6 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF7 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF8 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.CatF9 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF10 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF11 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF12 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF13 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF14 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF15 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF16 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CatF17 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF18 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF19 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF20 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF21 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF22 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF23 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF24 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.CatF25 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF26 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF27 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF28 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF29 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF30 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF31 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF32 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.CatF33 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF34 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF35 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF36 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF37 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF38 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF39 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CatF40 <- apc.fit( subset( CatF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


CatSmoothRate <- rbind(apc.CatF1[["Age"]],
                       apc.CatF2[["Age"]],
                       apc.CatF3[["Age"]],
                       apc.CatF4[["Age"]],
                       apc.CatF5[["Age"]],
                       apc.CatF6[["Age"]],
                       apc.CatF7[["Age"]],
                       apc.CatF8[["Age"]],
                       apc.CatF9[["Age"]],
                       apc.CatF10[["Age"]],
                       apc.CatF11[["Age"]],
                       apc.CatF12[["Age"]],
                       apc.CatF13[["Age"]],
                       apc.CatF14[["Age"]],
                       apc.CatF15[["Age"]],
                       apc.CatF16[["Age"]],
                       apc.CatF17[["Age"]],
                       apc.CatF18[["Age"]],
                       apc.CatF19[["Age"]],
                       apc.CatF20[["Age"]],
                       apc.CatF21[["Age"]],
                       apc.CatF22[["Age"]],
                       apc.CatF23[["Age"]],
                       apc.CatF24[["Age"]],
                       apc.CatF25[["Age"]],
                       apc.CatF26[["Age"]],
                       apc.CatF27[["Age"]],
                       apc.CatF28[["Age"]],
                       apc.CatF29[["Age"]],
                       apc.CatF30[["Age"]],
                       apc.CatF31[["Age"]],
                       apc.CatF32[["Age"]],
                       apc.CatF33[["Age"]],
                       apc.CatF34[["Age"]],
                       apc.CatF35[["Age"]],
                       apc.CatF36[["Age"]],
                       apc.CatF37[["Age"]],
                       apc.CatF38[["Age"]],
                       apc.CatF39[["Age"]],
                       apc.CatF40[["Age"]])





apc.ExtF1 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF2 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF3 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF4 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF5 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF6 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF7 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF8 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.ExtF9 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF10 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF11 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF12 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF13 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF14 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF15 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF16 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.ExtF17 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF18 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF19 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF20 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF21 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF22 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF23 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF24 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.ExtF25 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF26 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF27 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF28 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF29 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF30 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF31 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF32 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.ExtF33 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF34 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF35 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF36 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF37 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF38 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF39 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ExtF40 <- apc.fit( subset( ExtF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


ExtSmoothRate <- rbind(apc.ExtF1[["Age"]],
                       apc.ExtF2[["Age"]],
                       apc.ExtF3[["Age"]],
                       apc.ExtF4[["Age"]],
                       apc.ExtF5[["Age"]],
                       apc.ExtF6[["Age"]],
                       apc.ExtF7[["Age"]],
                       apc.ExtF8[["Age"]],
                       apc.ExtF9[["Age"]],
                       apc.ExtF10[["Age"]],
                       apc.ExtF11[["Age"]],
                       apc.ExtF12[["Age"]],
                       apc.ExtF13[["Age"]],
                       apc.ExtF14[["Age"]],
                       apc.ExtF15[["Age"]],
                       apc.ExtF16[["Age"]],
                       apc.ExtF17[["Age"]],
                       apc.ExtF18[["Age"]],
                       apc.ExtF19[["Age"]],
                       apc.ExtF20[["Age"]],
                       apc.ExtF21[["Age"]],
                       apc.ExtF22[["Age"]],
                       apc.ExtF23[["Age"]],
                       apc.ExtF24[["Age"]],
                       apc.ExtF25[["Age"]],
                       apc.ExtF26[["Age"]],
                       apc.ExtF27[["Age"]],
                       apc.ExtF28[["Age"]],
                       apc.ExtF29[["Age"]],
                       apc.ExtF30[["Age"]],
                       apc.ExtF31[["Age"]],
                       apc.ExtF32[["Age"]],
                       apc.ExtF33[["Age"]],
                       apc.ExtF34[["Age"]],
                       apc.ExtF35[["Age"]],
                       apc.ExtF36[["Age"]],
                       apc.ExtF37[["Age"]],
                       apc.ExtF38[["Age"]],
                       apc.ExtF39[["Age"]],
                       apc.ExtF40[["Age"]])





apc.GalF1 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF2 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF3 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF4 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF5 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF6 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF7 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF8 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.GalF9 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF10 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF11 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF12 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF13 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF14 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF15 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF16 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.GalF17 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF18 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF19 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF20 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF21 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF22 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF23 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF24 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.GalF25 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF26 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF27 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF28 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF29 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF30 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF31 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF32 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.GalF33 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF34 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF35 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF36 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF37 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF38 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF39 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.GalF40 <- apc.fit( subset( GalF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


GalSmoothRate <- rbind(apc.GalF1[["Age"]],
                       apc.GalF2[["Age"]],
                       apc.GalF3[["Age"]],
                       apc.GalF4[["Age"]],
                       apc.GalF5[["Age"]],
                       apc.GalF6[["Age"]],
                       apc.GalF7[["Age"]],
                       apc.GalF8[["Age"]],
                       apc.GalF9[["Age"]],
                       apc.GalF10[["Age"]],
                       apc.GalF11[["Age"]],
                       apc.GalF12[["Age"]],
                       apc.GalF13[["Age"]],
                       apc.GalF14[["Age"]],
                       apc.GalF15[["Age"]],
                       apc.GalF16[["Age"]],
                       apc.GalF17[["Age"]],
                       apc.GalF18[["Age"]],
                       apc.GalF19[["Age"]],
                       apc.GalF20[["Age"]],
                       apc.GalF21[["Age"]],
                       apc.GalF22[["Age"]],
                       apc.GalF23[["Age"]],
                       apc.GalF24[["Age"]],
                       apc.GalF25[["Age"]],
                       apc.GalF26[["Age"]],
                       apc.GalF27[["Age"]],
                       apc.GalF28[["Age"]],
                       apc.GalF29[["Age"]],
                       apc.GalF30[["Age"]],
                       apc.GalF31[["Age"]],
                       apc.GalF32[["Age"]],
                       apc.GalF33[["Age"]],
                       apc.GalF34[["Age"]],
                       apc.GalF35[["Age"]],
                       apc.GalF36[["Age"]],
                       apc.GalF37[["Age"]],
                       apc.GalF38[["Age"]],
                       apc.GalF39[["Age"]],
                       apc.GalF40[["Age"]])




apc.LRF1 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF2 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1981,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF3 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1982,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF4 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1983,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF5 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1984,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF6 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1985,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF7 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1986,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF8 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1987,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))



apc.LRF9 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1988,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF10 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1989,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF11 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1990,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF12 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1991,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF13 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1992,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF14 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1993,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF15 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1994,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF16 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1995,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.LRF17 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1996,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF18 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1997,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF19 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1998,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF20 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 1999,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF21 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2000,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF22 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2001,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF23 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2002,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF24 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2003,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.LRF25 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2004,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF26 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2005,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF27 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2006,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF28 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2007,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF29 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2008,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF30 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2009,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF31 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2010,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF32 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2011,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


apc.LRF33 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2012,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF34 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2013,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF35 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2014,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF36 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2015,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF37 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2016,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF38 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2017,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF39 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2018,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.LRF40 <- apc.fit( subset( LRF ),
                      parm = "APC",
                      ref.p = 2019,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


LRSmoothRate <- rbind(apc.LRF1[["Age"]],
                      apc.LRF2[["Age"]],
                      apc.LRF3[["Age"]],
                      apc.LRF4[["Age"]],
                      apc.LRF5[["Age"]],
                      apc.LRF6[["Age"]],
                      apc.LRF7[["Age"]],
                      apc.LRF8[["Age"]],
                      apc.LRF9[["Age"]],
                      apc.LRF10[["Age"]],
                      apc.LRF11[["Age"]],
                      apc.LRF12[["Age"]],
                      apc.LRF13[["Age"]],
                      apc.LRF14[["Age"]],
                      apc.LRF15[["Age"]],
                      apc.LRF16[["Age"]],
                      apc.LRF17[["Age"]],
                      apc.LRF18[["Age"]],
                      apc.LRF19[["Age"]],
                      apc.LRF20[["Age"]],
                      apc.LRF21[["Age"]],
                      apc.LRF22[["Age"]],
                      apc.LRF23[["Age"]],
                      apc.LRF24[["Age"]],
                      apc.LRF25[["Age"]],
                      apc.LRF26[["Age"]],
                      apc.LRF27[["Age"]],
                      apc.LRF28[["Age"]],
                      apc.LRF29[["Age"]],
                      apc.LRF30[["Age"]],
                      apc.LRF31[["Age"]],
                      apc.LRF32[["Age"]],
                      apc.LRF33[["Age"]],
                      apc.LRF34[["Age"]],
                      apc.LRF35[["Age"]],
                      apc.LRF36[["Age"]],
                      apc.LRF37[["Age"]],
                      apc.LRF38[["Age"]],
                      apc.LRF39[["Age"]],
                      apc.LRF40[["Age"]])




apc.MadF1 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF2 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF3 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF4 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF5 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF6 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF7 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF8 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.MadF9 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF10 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF11 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF12 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF13 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF14 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF15 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF16 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.MadF17 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF18 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF19 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF20 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF21 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF22 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF23 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF24 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.MadF25 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF26 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF27 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF28 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF29 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF30 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF31 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF32 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.MadF33 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF34 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF35 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF36 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF37 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF38 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF39 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MadF40 <- apc.fit( subset( MadF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


MadSmoothRate <- rbind(apc.MadF1[["Age"]],
                       apc.MadF2[["Age"]],
                       apc.MadF3[["Age"]],
                       apc.MadF4[["Age"]],
                       apc.MadF5[["Age"]],
                       apc.MadF6[["Age"]],
                       apc.MadF7[["Age"]],
                       apc.MadF8[["Age"]],
                       apc.MadF9[["Age"]],
                       apc.MadF10[["Age"]],
                       apc.MadF11[["Age"]],
                       apc.MadF12[["Age"]],
                       apc.MadF13[["Age"]],
                       apc.MadF14[["Age"]],
                       apc.MadF15[["Age"]],
                       apc.MadF16[["Age"]],
                       apc.MadF17[["Age"]],
                       apc.MadF18[["Age"]],
                       apc.MadF19[["Age"]],
                       apc.MadF20[["Age"]],
                       apc.MadF21[["Age"]],
                       apc.MadF22[["Age"]],
                       apc.MadF23[["Age"]],
                       apc.MadF24[["Age"]],
                       apc.MadF25[["Age"]],
                       apc.MadF26[["Age"]],
                       apc.MadF27[["Age"]],
                       apc.MadF28[["Age"]],
                       apc.MadF29[["Age"]],
                       apc.MadF30[["Age"]],
                       apc.MadF31[["Age"]],
                       apc.MadF32[["Age"]],
                       apc.MadF33[["Age"]],
                       apc.MadF34[["Age"]],
                       apc.MadF35[["Age"]],
                       apc.MadF36[["Age"]],
                       apc.MadF37[["Age"]],
                       apc.MadF38[["Age"]],
                       apc.MadF39[["Age"]],
                       apc.MadF40[["Age"]])





apc.MurF1 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF2 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF3 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF4 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF5 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF6 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF7 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF8 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.MurF9 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF10 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF11 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF12 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF13 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF14 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF15 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF16 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.MurF17 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF18 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF19 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF20 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF21 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF22 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF23 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF24 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.MurF25 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF26 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF27 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF28 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF29 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF30 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF31 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF32 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.MurF33 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF34 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF35 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF36 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF37 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF38 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF39 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.MurF40 <- apc.fit( subset( MurF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


MurSmoothRate <- rbind(apc.MurF1[["Age"]],
                       apc.MurF2[["Age"]],
                       apc.MurF3[["Age"]],
                       apc.MurF4[["Age"]],
                       apc.MurF5[["Age"]],
                       apc.MurF6[["Age"]],
                       apc.MurF7[["Age"]],
                       apc.MurF8[["Age"]],
                       apc.MurF9[["Age"]],
                       apc.MurF10[["Age"]],
                       apc.MurF11[["Age"]],
                       apc.MurF12[["Age"]],
                       apc.MurF13[["Age"]],
                       apc.MurF14[["Age"]],
                       apc.MurF15[["Age"]],
                       apc.MurF16[["Age"]],
                       apc.MurF17[["Age"]],
                       apc.MurF18[["Age"]],
                       apc.MurF19[["Age"]],
                       apc.MurF20[["Age"]],
                       apc.MurF21[["Age"]],
                       apc.MurF22[["Age"]],
                       apc.MurF23[["Age"]],
                       apc.MurF24[["Age"]],
                       apc.MurF25[["Age"]],
                       apc.MurF26[["Age"]],
                       apc.MurF27[["Age"]],
                       apc.MurF28[["Age"]],
                       apc.MurF29[["Age"]],
                       apc.MurF30[["Age"]],
                       apc.MurF31[["Age"]],
                       apc.MurF32[["Age"]],
                       apc.MurF33[["Age"]],
                       apc.MurF34[["Age"]],
                       apc.MurF35[["Age"]],
                       apc.MurF36[["Age"]],
                       apc.MurF37[["Age"]],
                       apc.MurF38[["Age"]],
                       apc.MurF39[["Age"]],
                       apc.MurF40[["Age"]])




apc.NavF1 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF2 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF3 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF4 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF5 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF6 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF7 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF8 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.NavF9 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF10 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF11 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF12 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF13 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF14 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF15 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF16 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.NavF17 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF18 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF19 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF20 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF21 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF22 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF23 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF24 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.NavF25 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF26 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF27 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF28 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF29 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF30 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF31 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF32 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.NavF33 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF34 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF35 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF36 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF37 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF38 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF39 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.NavF40 <- apc.fit( subset( NavF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


NavSmoothRate <- rbind(apc.NavF1[["Age"]],
                       apc.NavF2[["Age"]],
                       apc.NavF3[["Age"]],
                       apc.NavF4[["Age"]],
                       apc.NavF5[["Age"]],
                       apc.NavF6[["Age"]],
                       apc.NavF7[["Age"]],
                       apc.NavF8[["Age"]],
                       apc.NavF9[["Age"]],
                       apc.NavF10[["Age"]],
                       apc.NavF11[["Age"]],
                       apc.NavF12[["Age"]],
                       apc.NavF13[["Age"]],
                       apc.NavF14[["Age"]],
                       apc.NavF15[["Age"]],
                       apc.NavF16[["Age"]],
                       apc.NavF17[["Age"]],
                       apc.NavF18[["Age"]],
                       apc.NavF19[["Age"]],
                       apc.NavF20[["Age"]],
                       apc.NavF21[["Age"]],
                       apc.NavF22[["Age"]],
                       apc.NavF23[["Age"]],
                       apc.NavF24[["Age"]],
                       apc.NavF25[["Age"]],
                       apc.NavF26[["Age"]],
                       apc.NavF27[["Age"]],
                       apc.NavF28[["Age"]],
                       apc.NavF29[["Age"]],
                       apc.NavF30[["Age"]],
                       apc.NavF31[["Age"]],
                       apc.NavF32[["Age"]],
                       apc.NavF33[["Age"]],
                       apc.NavF34[["Age"]],
                       apc.NavF35[["Age"]],
                       apc.NavF36[["Age"]],
                       apc.NavF37[["Age"]],
                       apc.NavF38[["Age"]],
                       apc.NavF39[["Age"]],
                       apc.NavF40[["Age"]])




apc.ValF1 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF2 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1981,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF3 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1982,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF4 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1983,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF5 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1984,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF6 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1985,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF7 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1986,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF8 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1987,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))



apc.ValF9 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1988,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF10 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1989,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF11 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1990,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF12 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1991,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF13 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1992,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF14 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1993,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF15 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1994,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF16 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1995,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.ValF17 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1996,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF18 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1997,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF19 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1998,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF20 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 1999,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF21 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2000,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF22 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2001,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF23 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2002,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF24 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2003,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))



apc.ValF25 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2004,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF26 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2005,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF27 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2006,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF28 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2007,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF29 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2008,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF30 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2009,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF31 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2010,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF32 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2011,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


apc.ValF33 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2012,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF34 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2013,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF35 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2014,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF36 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2015,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF37 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2016,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF38 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2017,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF39 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2018,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.ValF40 <- apc.fit( subset( ValF ),
                       parm = "APC",
                       ref.p = 2019,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


ValSmoothRate <- rbind(apc.ValF1[["Age"]],
                       apc.ValF2[["Age"]],
                       apc.ValF3[["Age"]],
                       apc.ValF4[["Age"]],
                       apc.ValF5[["Age"]],
                       apc.ValF6[["Age"]],
                       apc.ValF7[["Age"]],
                       apc.ValF8[["Age"]],
                       apc.ValF9[["Age"]],
                       apc.ValF10[["Age"]],
                       apc.ValF11[["Age"]],
                       apc.ValF12[["Age"]],
                       apc.ValF13[["Age"]],
                       apc.ValF14[["Age"]],
                       apc.ValF15[["Age"]],
                       apc.ValF16[["Age"]],
                       apc.ValF17[["Age"]],
                       apc.ValF18[["Age"]],
                       apc.ValF19[["Age"]],
                       apc.ValF20[["Age"]],
                       apc.ValF21[["Age"]],
                       apc.ValF22[["Age"]],
                       apc.ValF23[["Age"]],
                       apc.ValF24[["Age"]],
                       apc.ValF25[["Age"]],
                       apc.ValF26[["Age"]],
                       apc.ValF27[["Age"]],
                       apc.ValF28[["Age"]],
                       apc.ValF29[["Age"]],
                       apc.ValF30[["Age"]],
                       apc.ValF31[["Age"]],
                       apc.ValF32[["Age"]],
                       apc.ValF33[["Age"]],
                       apc.ValF34[["Age"]],
                       apc.ValF35[["Age"]],
                       apc.ValF36[["Age"]],
                       apc.ValF37[["Age"]],
                       apc.ValF38[["Age"]],
                       apc.ValF39[["Age"]],
                       apc.ValF40[["Age"]])




CombinedSmoothRate <- rbind(AvgSmoothRate,
                            AndSmoothRate,
                            AraSmoothRate,
                            AstSmoothRate,
                            BalSmoothRate,
                            PVSmoothRate,
                            CanSmoothRate,
                            CantSmoothRate,
                            CyLSmoothRate,
                            CLMSmoothRate,
                            CatSmoothRate,
                            ExtSmoothRate,
                            GalSmoothRate,
                            LRSmoothRate,
                            MadSmoothRate,
                            MurSmoothRate,
                            NavSmoothRate,
                            ValSmoothRate)



CombinedSmoothRate <- as.data.frame(CombinedSmoothRate)


CombinedSmoothRate$Period <- rep(c(rep(1980,9),
                                   rep(1981,9),
                                   rep(1982,9),
                                   rep(1983,9),
                                   rep(1984,9),
                                   rep(1985,9),
                                   rep(1986,9),
                                   rep(1987,9),
                                   rep(1988,9),
                                   rep(1989,9),
                                   rep(1990,9),
                                   rep(1991,9),
                                   rep(1992,9),
                                   rep(1993,9),
                                   rep(1994,9),
                                   rep(1995,9),
                                   rep(1996,9),
                                   rep(1997,9),
                                   rep(1998,9),
                                   rep(1999,9),
                                   rep(2000,9),
                                   rep(2001,9),
                                   rep(2002,9),
                                   rep(2003,9),
                                   rep(2004,9),
                                   rep(2005,9),
                                   rep(2006,9),
                                   rep(2007,9),
                                   rep(2008,9),
                                   rep(2009,9),
                                   rep(2010,9),
                                   rep(2011,9),
                                   rep(2012,9),
                                   rep(2013,9),
                                   rep(2014,9),
                                   rep(2015,9),
                                   rep(2016,9),
                                   rep(2017,9),
                                   rep(2018,9),
                                   rep(2019,9)),18)


CombinedSmoothRate$CCAA <- c(rep("Spain",72),
                             rep("Andalusia",72),
                             rep("Aragon",72),
                             rep("Asturias",72),
                             rep("Balearic Islands",72),
                             rep("Basque Country",72),
                             rep("Canary Islands",72),
                             rep("Cantabria",72),
                             rep("Castile & Leon",72),
                             rep("Castile-La Mancha",72),
                             rep("Catalonia",72),
                             rep("Extremadura",72),
                             rep("Galicia",72),
                             rep("La Rioja",72),
                             rep("Madrid",72),
                             rep("Murcia",72),
                             rep("Navarra",72),
                             rep("Valencian Community",72))



CombinedSmoothRate2 <- CombinedSmoothRate %>% 
  group_by(Period,CCAA) %>% 
  mutate(ch = ((Rate / lag(Rate)) - 1) * 100,
         ch2 = Rate/lag(Rate)) %>% 
  ungroup() %>% 
  drop_na()



CombinedSmoothRate$CCAA <-  factor(CombinedSmoothRate$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                              "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                              "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))


ggplot(CombinedSmoothRate,aes(x=Period,y=Age,z=log(Rate)))+
  geom_tile(aes(fill=log(Rate)),alpha=1,
            linetype=1) +
  geom_contour(breaks=c(1,2,3,4), col = "black", size = .15, alpha = 1)+
  # geom_contour(aes(z = Period-Age),breaks=c(5,15,20,50,75), alpha=1, color="black", size=.3)+ 
  geom_text_contour(aes(z = Period-Age), skip=0, label.placer = label_placement_n(1), stroke = 0.15) +
  scale_fill_viridis(option = "D", discrete = F,  direction = -1)+
  # scale_fill_gradient(low = "yellow", high = "purple") +
  # theme_bw()+
  # scale_y_log10()+
  # scale_x_log10()+
  # scale_colour_manual(values = Rate, limits = c("0","100000"))+
  # scale_fill_manual(limits= c("sienna1","hotpink1"))+
  labs(x="Year"
       ,y="Age",
       fill="Log Death Rate 
       (per 100000)")+
  lexis_shape+
  facet_wrap(~CCAA,ncol = 6)

# 
# 
# ggplot(CombinedSmoothRate2,aes(x=Period,y=Age,z=log(ch2)))+
#   geom_tile(aes(fill=log(ch2)),alpha=1,
#             linetype=1) +
#   # geom_contour(breaks=c(0.25,0.5,1,2), col = "black", size = .15, alpha = 1)+
#   geom_contour(aes(z = Period-Age),breaks=c(5,15,20,50,75), alpha=1, color="black", size=.3)+ 
#   geom_text_contour(aes(z = Period-Age), stroke = 0.15) +
#   scale_fill_viridis(option = "D", discrete = F,  direction = -1)+
#   # scale_fill_gradient(low = "yellow", high = "purple") +
#   # theme_bw()+
#   # scale_y_log10()+
#   # scale_x_log10()+
#   # scale_colour_manual(values = Rate, limits = c("0","100000"))+
#   # scale_fill_manual(limits= c("sienna1","hotpink1"))+
#   labs(x="Year"
#        ,y="Age",
#        fill="Log Death Rate 
#        (per 100000)")+
#   lexis_shape+
#   facet_wrap(~CCAA,ncol = 6)
# 
# 


