rm(list=ls())
# read packages

library(openxlsx)
library(dplyr)
library(readxl)
library(tidyr)
library(tidyverse)
library(MortalitySmooth)
library(ungroup)
library(Epi)
library(splines)
library(readr)

#read lung larynx and other cancer deaths and merge 


LungDeaths1 <- read_delim("C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/LungMortalitySpain.txt", 
                          "\t", escape_double = FALSE, trim_ws = TRUE)

LungDeaths2 <- read_delim("C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/LarynxMortalitySpain.txt", 
                          "\t", escape_double = FALSE, trim_ws = TRUE)

LungDeaths3 <- read_delim("C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/OtherRespMortalitySpain.txt", 
                          "\t", escape_double = FALSE, trim_ws = TRUE)

CancerDeaths <- rbind(LungDeaths1,LungDeaths2,LungDeaths3)

# summarize to get age 40 and above 

Cancer40 <- CancerDeaths %>% 
  pivot_longer(cols= starts_with(c("2", "1")),
               names_to = "Periodo",
               values_to = "Deaths")  %>% 
  filter(Edad>35, CCAA != "Nacional") %>% 
  group_by(Sexo,Edad,CCAA,Periodo) %>% 
  summarize(Deaths=sum(Deaths))


# merge into 5 age groups due to some tabulations having 0 obs (apc.fit crashes )
# 
# Cancer40$Edad [Cancer40$Edad > 82.5]<-87.5
# Cancer40$Period [Cancer40$Periodo > 1979 & Cancer40$Periodo < 1985]<-1982.5
# Cancer40$Period [Cancer40$Periodo > 1984 & Cancer40$Periodo < 1990]<-1987.5
# Cancer40$Period [Cancer40$Periodo > 1989 & Cancer40$Periodo < 1995]<-1992.5
# Cancer40$Period [Cancer40$Periodo > 1994 & Cancer40$Periodo < 2000]<-1997.5
# Cancer40$Period [Cancer40$Periodo > 1999 & Cancer40$Periodo < 2005]<-2002.5
# Cancer40$Period [Cancer40$Periodo > 2004 & Cancer40$Periodo < 2010]<-2007.5
# Cancer40$Period [Cancer40$Periodo > 2009 & Cancer40$Periodo < 2015]<-2012.5
# Cancer40$Period [Cancer40$Periodo > 2014 & Cancer40$Periodo < 2020]<-2017.5

# filter out foreign

Cancer40Reg <- Cancer40 %>%  
  filter(CCAA !="Extranjero" ) %>% 
  group_by(Sexo,CCAA,Edad,Periodo) %>% 
  summarize(Cases=sum(Deaths))


table(Cancer40Reg$CCAA)
table(Cancer40Reg$Sexo)
table(Cancer40Reg$Edad)
table(Cancer40Reg$Periodo)

table(Cancer40Reg$CCAA,Cancer40Reg$Sexo)
table(Cancer40Reg$CCAA,Cancer40Reg$Edad)
table(Cancer40Reg$CCAA,Cancer40Reg$Periodo)
table(Cancer40Reg$Periodo,Cancer40Reg$Sexo)

# read population and check NA

Popspain <- read_delim("C:/Users/obramajo/Desktop/Tesis Bramajo/PobEspa�a40ymas19802019.txt", 
                       "\t", escape_double = FALSE, trim_ws = TRUE)          

# five year bins for pop 

table(is.na(Popspain$Total))

Popspain$Total[is.na(Popspain$Total)] <- 0  

PopspainReg<- as.data.frame(Popspain)
Popspain$Periodo<- as.numeric(Popspain$Periodo)


PopspainReg$Edad [PopspainReg$Edad > 39 & PopspainReg$Edad < 45]<- 42.5
PopspainReg$Edad [PopspainReg$Edad > 44 & PopspainReg$Edad < 50]<- 47.5
PopspainReg$Edad [PopspainReg$Edad > 49 & PopspainReg$Edad < 55]<- 52.5
PopspainReg$Edad [PopspainReg$Edad > 54 & PopspainReg$Edad < 60]<- 57.5
PopspainReg$Edad [PopspainReg$Edad > 59 & PopspainReg$Edad < 65]<- 62.5
PopspainReg$Edad [PopspainReg$Edad > 64 & PopspainReg$Edad < 70]<- 67.5
PopspainReg$Edad [PopspainReg$Edad > 69 & PopspainReg$Edad < 75]<- 72.5
PopspainReg$Edad [PopspainReg$Edad > 74 & PopspainReg$Edad < 80]<- 77.5
PopspainReg$Edad [PopspainReg$Edad > 79 & PopspainReg$Edad < 85]<- 82.5
PopspainReg$Edad [PopspainReg$Edad > 84 & PopspainReg$Edad < 860]<- 87.5
PopspainReg$Period [PopspainReg$Periodo > 1979 & PopspainReg$Periodo < 1985]<- 1982.5
PopspainReg$Period [PopspainReg$Periodo > 1984 & PopspainReg$Periodo < 1990]<- 1987.5
PopspainReg$Period [PopspainReg$Periodo > 1989 & PopspainReg$Periodo < 1995]<- 1992.5
PopspainReg$Period [PopspainReg$Periodo > 1994 & PopspainReg$Periodo < 2000]<- 1997.5
PopspainReg$Period [PopspainReg$Periodo > 1999 & PopspainReg$Periodo < 2005]<- 2002.5
PopspainReg$Period [PopspainReg$Periodo > 2004 & PopspainReg$Periodo < 2010]<- 2007.5
PopspainReg$Period [PopspainReg$Periodo > 2009 & PopspainReg$Periodo < 2015]<- 2012.5
PopspainReg$Period [PopspainReg$Periodo > 2014 & PopspainReg$Periodo < 2020]<- 2017.5

table(PopspainReg$CCAA)

PopspainReg<- PopspainReg%>% 
  filter(CCAA !="Nacional" ) %>%
  group_by(Sexo,CCAA,Edad,Periodo) %>% 
  summarize(Pop=sum(Total)) 

Cancer40Reg$Pop 

Cancer40Reg$Pop <- PopspainReg$Pop

Cancer40Reg$Periodo<- as.numeric(Cancer40Reg$Periodo)
Cancer40Reg$Cohort<-Cancer40Reg$Periodo-Cancer40Reg$Edad


Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Arag�n"] <- "Aragon"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Asturias"] <- "Asturias"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Cantabria"] <- "Cantabria"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Castilla  - La Mancha"] <- "Castile-La Mancha"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Ceuta"] <- "Ceuta and Melilla"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Extremadura"] <- "Extremadura"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Islas Baleares"] <- "Balearic Islands"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="La Rioja"] <- "La Rioja"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Melilla"] <- "Ceuta and Melilla"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Murcia"] <- "Murcia"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Navarra"] <- "Navarra"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Andaluc�a"] <- "Andalusia"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Catalu�a"] <- "Catalonia"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Valencia"] <- "Valencian Community"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Pa�s Vasco"] <- "Basque Country"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Castilla y Le�n"] <- "Castile & Leon"
Cancer40Reg$CCAA[Cancer40Reg$CCAA=="Islas Canarias"] <- "Canary Islands"

Cancer40Reg$Sexo[Cancer40Reg$Sexo=="Hombres"] <- "Males"
Cancer40Reg$Sexo[Cancer40Reg$Sexo=="Mujeres"] <- "Females"


table(PopspainReg$CCAA)

PopspainReg$CCAA[PopspainReg$CCAA=="Arag�n"] <- "Aragon"
PopspainReg$CCAA[PopspainReg$CCAA=="Asturias"] <- "Asturias"
PopspainReg$CCAA[PopspainReg$CCAA=="Cantabria"] <- "Cantabria"
PopspainReg$CCAA[PopspainReg$CCAA=="Castilla_La-Mancha"] <- "Castile-La Mancha"
PopspainReg$CCAA[PopspainReg$CCAA=="Ceuta"] <- "Ceuta and Melilla"
PopspainReg$CCAA[PopspainReg$CCAA=="Extremadura"] <- "Extremadura"
PopspainReg$CCAA[PopspainReg$CCAA=="Islas_Baleares"] <- "Balearic Islands"
PopspainReg$CCAA[PopspainReg$CCAA=="La_Rioja"] <- "La Rioja"
PopspainReg$CCAA[PopspainReg$CCAA=="Melilla"] <- "Ceuta and Melilla"
PopspainReg$CCAA[PopspainReg$CCAA=="Murcia"] <- "Murcia"
PopspainReg$CCAA[PopspainReg$CCAA=="Navarra"] <- "Navarra"
PopspainReg$CCAA[PopspainReg$CCAA=="Andaluc�a"] <- "Andalusia"
PopspainReg$CCAA[PopspainReg$CCAA=="Catalu�a"] <- "Catalonia"
PopspainReg$CCAA[PopspainReg$CCAA=="Valencia"] <- "Valencian Community"
PopspainReg$CCAA[PopspainReg$CCAA=="Pa�s_Vasco"] <- "Basque Country"
PopspainReg$CCAA[PopspainReg$CCAA=="Castilla_y_Le�n"] <- "Castile & Leon"
PopspainReg$CCAA[PopspainReg$CCAA=="Islas_Canarias"] <- "Canary Islands"


PopspainReg$Sexo[PopspainReg$Sexo=="Hombres"] <- "Males"
PopspainReg$Sexo[PopspainReg$Sexo=="Mujeres"] <- "Females"


# filter out Ceuta and Melilla. Make a new object just in case

Cancer40Reg2 <-  Cancer40Reg %>% 
  filter(Edad < 85,CCAA != "Ceuta and Melilla") 


Cancer40Reg2 <- left_join(Cancer40Reg2,PopspainReg, by=c("Sexo","CCAA","Edad","Periodo"))


# get values per autonomous community

Cancer40Reg2 <- Cancer40Reg2 %>%
  group_by(Sexo,CCAA,Edad,Periodo) %>% 
  summarize(Cases=sum(Cases),
            Pop=sum(Pop)) %>% 
  mutate(Cohort=Periodo-Edad)

# get national values

SpainAvg <- Cancer40Reg2 %>%
  group_by(Sexo,Edad,Periodo,Cohort) %>% 
  summarize(Cases=sum(Cases),
            Pop=sum(Pop))


SpainAvg$CCAA <- "Spain"

SpainAvg<- SpainAvg[c(1,7,2,3,5,6,4)]

# bind national avg and CCAA


Cancer40Reg2 <- rbind(Cancer40Reg2,SpainAvg)

table(Cancer40Reg2$Cases==0)

Cancer40Reg2$Rate <- Cancer40Reg2$Cases/Cancer40Reg2$Pop


##Obtain Standardized Rates and filter for females

CancerFemales <- Cancer40Reg2 %>% 
  filter(Sexo=="Females")

# deaths in 1980 and 2019 and plot
Alldeaths19802019<- CancerFemales %>% 
  group_by(Periodo)%>%
  summarize(Deaths=sum(Cases)/2)


ggplot(Alldeaths19802019,aes(x=Periodo,y=Deaths))+
  geom_point()+
  theme_bw()+
  labs(y = "Female Deaths due to lung cancer", x = "Year")+
  theme(text= element_text(size=12),
        axis.text.x = element_text(angle = 90, vjust = 0.1, hjust=2))

theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  scale_fill_manual("Component", values = c("Morbidity" = "red", "Mortality" = "black", "All" = "orange"))+
  geom_text(aes(label = round(Contribution,2), angle=0), vjust = -2.5, position = position_dodge(.9),size=3)+
  facet_wrap(~ Sex+gap)



StructureVector<- CancerFemales %>% 
  filter(Periodo=="2019") %>%
  group_by(Edad)%>%
  summarize(Stand=sum(Pop))

overall<-sum(StructureVector$Stand)
StructureVector$Prop <- StructureVector$Stand/overall
# 
# Age_Groups<-c("40-44","45-49","50-54","55-59","60-64","65-69",
#               "70-74","75-79","80+")

CancerFemales <- CancerFemales %>% 
  arrange(Periodo,Sexo,CCAA)

CancerFemales$PropRef <- rep(StructureVector$Prop, length.out=6480) 
CancerFemales$Age_Groups<-rep(Age_Groups, length.out=6480) 
CancerFemales$PeriodF <-as.factor(CancerFemales$Periodo)
CancerFemales$CohortF <-as.factor(CancerFemales$Cohort)
CancerFemales$Standrate<-CancerFemales$Rate*CancerFemales$PropRef


SRATEALL <- CancerFemales %>%
  group_by(CCAA,Periodo)  %>%
  summarize(Cruderate=sum(Rate)*1000,
            Standardizedrate=sum(Standrate)*10000)  


SRATEALL$CCAA2 <-  factor(SRATEALL$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                   "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                   "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))
CancerFemales$CCAA2 <- factor(CancerFemales$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                            "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                            "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))
# CancerFemales$Years[CancerFemales$PeriodF[CancerFemales$PeriodF=="1982.5"]] <- "1980-84"
# 
# CancerFemales$Years[CancerFemales$PeriodF=="1982.5"] <- "1980-84"   
# CancerFemales$Years[CancerFemales$PeriodF=="1987.5"] <- "1985-89"   
# CancerFemales$Years[CancerFemales$PeriodF=="1992.5"] <- "1990-94"   
# CancerFemales$Years[CancerFemales$PeriodF=="1997.5"] <- "1995-99"   
# CancerFemales$Years[CancerFemales$PeriodF=="2002.5"] <- "2000-04"   
# CancerFemales$Years[CancerFemales$PeriodF=="2007.5"] <- "2005-09"   
# CancerFemales$Years[CancerFemales$PeriodF=="2012.5"] <- "2010-14"   
# CancerFemales$Years[CancerFemales$PeriodF=="2017.5"] <- "2015-19" 
# table(CancerFemales$CohortF)
# 
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1900"] <- "Before 1901"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1905"] <- "1901-05"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1910"] <- "1906-10"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1915"] <- "1911-15"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1920"] <- "1916-20"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1925"] <- "1921-25"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1930"] <- "1926-30" 
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1935"] <- "1931-35"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1940"] <- "1936-40"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1945"] <- "1941-45"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1950"] <- "1946-50"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1955"] <- "1951-55"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1960"] <- "1956-60"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1965"] <- "1961-65" 
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1970"] <- "1966-70"   
# CancerFemales$Birth_Cohorts[CancerFemales$CohortF=="1975"] <- "1971-75" 


ggplot(SRATEALL,aes(x=Periodo,y=Standardizedrate*10, color=CCAA2))+
  geom_point()+
  geom_line()+
  theme_bw()+
  # geom_vline(xintercept = 1992.5,color = "red")+
  # geom_hline(yintercept = 15,color = "red")+
  labs(x="Year",
       y="Age-Standardized Death Rate (by 100000)")+
  scale_colour_discrete("Autonomous Communities")+
  facet_wrap(~CCAA2, ncol = 3)+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1, size=10))


###2D plots, females

ggplot(CancerFemales,aes(x=Edad,y=Rate*100000,color=as.factor(Periodo)))+
  geom_line()+
  theme_bw()+
  scale_y_log10()+
  scale_x_log10()+
  labs(x="Age"
       ,y="Death Rate")+
  facet_wrap(~CCAA2,ncol = 3)


ggplot(CancerFemales,aes(x=Periodo,y=Rate*100000,color=as.factor(Edad)))+
  geom_line()+
  theme_bw()+
  scale_y_log10()+
  scale_x_log10()+
  labs(x="Period"
       ,y="Death Rate")+
  facet_wrap(~CCAA2,ncol = 3)

table(is.na(Cancer40Reg2$CCAA))

table(is.na(Cancer40Reg2$Rate))
which(is.na(Cancer40Reg2$CCAA))

ggplot(CancerFemales,aes(x=Edad,y=Rate*100000,color=as.factor(Cohort)))+
  geom_line()+
  theme_bw()+
  scale_y_log10()+
  scale_x_log10()+
  labs(x="Age"
       ,y="Death Rate")+
  facet_wrap(~CCAA2,ncol = 3)


ggplot(CancerFemales,aes(x=Cohort,y=Rate*100000,color=as.factor(Edad)))+
  geom_line()+
  theme_bw()+
  scale_y_log10()+
  scale_x_log10()+
  labs(x="Birth Cohorts"
       ,y="Death Rate")+
  facet_wrap(~CCAA2,ncol = 3)

# prepare for APC Models 

CANCERALL <- CancerFemales  %>%
  filter(Edad < 85) %>%
  group_by(CCAA,Edad,Periodo,Cohort)  %>%
  summarize(Exposure=mean(Pop),
            Deaths=mean(Cases))

APCCANCERSEX <- CANCERALL %>% 
  select(Edad,Periodo,Deaths,Exposure,CCAA) %>%
  rename(A=Edad,P=Periodo,D=Deaths,Y=Exposure)

##Setting Autonomous Communities for APC Analysis

















##Setting Autonomous Communities for APC Analysis



AvgF <- APCCANCERSEX %>% 
  filter(CCAA=="Spain")
AndF <- APCCANCERSEX %>% 
  filter(CCAA=="Andalusia")
AraF <- APCCANCERSEX %>% 
  filter(CCAA=="Aragon")
AstF <- APCCANCERSEX %>% 
  filter(CCAA=="Asturias")
BalF <- APCCANCERSEX %>% 
  filter(CCAA=="Balearic Islands")
PVF <- APCCANCERSEX %>% 
  filter(CCAA=="Basque Country")
CanF <- APCCANCERSEX %>% 
  filter(CCAA=="Canary Islands")
CantF <- APCCANCERSEX %>% 
  filter(CCAA=="Cantabria")
CyLF <- APCCANCERSEX %>% 
  filter(CCAA=="Castile & Leon")
CLMF <- APCCANCERSEX %>% 
  filter(CCAA=="Castile-La Mancha")
CatF <- APCCANCERSEX %>% 
  filter(CCAA=="Catalonia")
ExtF <- APCCANCERSEX %>% 
  filter(CCAA=="Extremadura")
GalF <- APCCANCERSEX %>% 
  filter(CCAA=="Galicia")
LRF <- APCCANCERSEX %>% 
  filter(CCAA=="La Rioja")
MadF <- APCCANCERSEX %>% 
  filter(CCAA=="Madrid")
MurF <- APCCANCERSEX %>% 
  filter(CCAA=="Murcia")
NavF <- APCCANCERSEX %>% 
  filter(CCAA=="Navarra")
ValF <- APCCANCERSEX %>% 
  filter(CCAA=="Valencian Community")

###Females, APC


apc.AvgF <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AndF <- apc.fit( subset( AndF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AraF <- apc.fit( subset( AraF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AstF <- apc.fit( subset( AstF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.BalF <- apc.fit( subset( BalF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF <- apc.fit( subset( PVF ),
                    parm = "APC",
                    ref.p = 1980,
                    scale=100000,
                    npar=c(A=5, P=5, C=5))


apc.CanF <- apc.fit( subset( CanF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.CantF <- apc.fit( subset( CantF ),
                      parm = "APC",
                      ref.p = 1980,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF <- apc.fit( subset( CyLF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.CLMF <- apc.fit( subset( CLMF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.CatF <- apc.fit( subset( CatF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.ExtF <- apc.fit( subset( ExtF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.GalF <- apc.fit( subset( GalF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF <- apc.fit( subset( LRF ),
                    parm = "APC",
                    ref.p = 1980,
                    scale=100000,
                    npar=c(A=5, P=5, C=5))

apc.MadF <- apc.fit( subset( MadF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.MurF <- apc.fit( subset( MurF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.NavF <- apc.fit( subset( NavF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))


apc.ValF <- apc.fit( subset( ValF ),
                     parm = "APC",
                     ref.p = 1980,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))




###ANALYSIS OF DEVIANCE

anova1 <- apc.AvgF[["Anova"]]
anova2 <- apc.AndF[["Anova"]]
anova3 <- apc.AraF[["Anova"]]
anova4 <- apc.AstF[["Anova"]]
anova5 <- apc.BalF[["Anova"]]
anova6 <- apc.PVF[["Anova"]]
anova7 <- apc.CanF[["Anova"]]
anova8 <- apc.CantF[["Anova"]]
anova9 <- apc.CyLF[["Anova"]]
anova10 <- apc.CLMF[["Anova"]]
anova11 <- apc.CatF[["Anova"]]
anova12 <- apc.ExtF[["Anova"]]
anova13 <- apc.GalF[["Anova"]]
anova14 <- apc.LRF[["Anova"]]
anova15 <- apc.MadF[["Anova"]]
anova16 <- apc.MurF[["Anova"]]
anova17 <- apc.NavF[["Anova"]]
anova18 <- apc.ValF[["Anova"]]


allanovas <- rbind(anova1,anova2,anova3,anova4,anova5,anova6,
                   anova7,anova8,anova9,anova10,anova11,anova12,anova13,
                   anova14,anova15,anova16,anova17,anova18)


NamesVec <- c(rep("Spain",6),
              rep("Andalusia",6),
              rep("Aragon",6),
              rep("Asturias",6),
              rep("Balearic Islands",6),
              rep("Basque Country",6),
              rep("Canary Islands",6),
              rep("Cantabria",6),
              rep("Castile & Leon",6),
              rep("Castile-La Mancha",6),
              rep("Catalonia",6),
              rep("Extremadura",6),
              rep("Galicia",6),
              rep("La Rioja",6),
              rep("Madrid",6),
              rep("Murcia",6),
              rep("Navarra",6),
              rep("Valencian Community",6))

allanovas$CCAA <- NamesVec

allanovas$`Test df.`[is.na(allanovas$`Test df.`)] <- 3

allanovas2 <- allanovas %>% 
  filter(`Test df.` !="1",
         Model != "Age-Cohort") %>% 
  group_by(CCAA)

allanovas2$SumAgeMod <- c(rep(allanovas2$`Mod. dev.`[1],4),
                          rep(allanovas2$`Mod. dev.`[5],4),
                          rep(allanovas2$`Mod. dev.`[9],4),
                          rep(allanovas2$`Mod. dev.`[13],4),
                          rep(allanovas2$`Mod. dev.`[17],4),
                          rep(allanovas2$`Mod. dev.`[21],4),
                          rep(allanovas2$`Mod. dev.`[25],4),
                          rep(allanovas2$`Mod. dev.`[29],4),
                          rep(allanovas2$`Mod. dev.`[33],4),
                          rep(allanovas2$`Mod. dev.`[37],4),
                          rep(allanovas2$`Mod. dev.`[41],4),
                          rep(allanovas2$`Mod. dev.`[45],4),
                          rep(allanovas2$`Mod. dev.`[49],4),
                          rep(allanovas2$`Mod. dev.`[53],4),
                          rep(allanovas2$`Mod. dev.`[57],4),
                          rep(allanovas2$`Mod. dev.`[61],4),
                          rep(allanovas2$`Mod. dev.`[65],4),
                          rep(allanovas2$`Mod. dev.`[69],4))

allanovas2 <- allanovas2 %>%
  mutate(DifAgeMod= SumAgeMod -`Mod. dev.`) %>% 
  group_by(CCAA) %>% 
  filter(DifAgeMod >0)


allanovas2$AllDifMod <- c(rep(allanovas2$DifAgeMod[1],3),
                          rep(allanovas2$DifAgeMod[4],3),
                          rep(allanovas2$DifAgeMod[7],3),
                          rep(allanovas2$DifAgeMod[10],3),
                          rep(allanovas2$DifAgeMod[13],3),
                          rep(allanovas2$DifAgeMod[16],3),
                          rep(allanovas2$DifAgeMod[19],3),
                          rep(allanovas2$DifAgeMod[22],3),
                          rep(allanovas2$DifAgeMod[25],3),
                          rep(allanovas2$DifAgeMod[28],3),
                          rep(allanovas2$DifAgeMod[31],3),
                          rep(allanovas2$DifAgeMod[34],3),
                          rep(allanovas2$DifAgeMod[37],3),
                          rep(allanovas2$DifAgeMod[40],3),
                          rep(allanovas2$DifAgeMod[43],3),
                          rep(allanovas2$DifAgeMod[46],3),
                          rep(allanovas2$DifAgeMod[49],3),
                          rep(allanovas2$DifAgeMod[52],3))

library(readr)

# I printed results into xls and read here because it's easier, results should be identical 

AllAnovasDoneforplot <- read_delim("C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/AllAnovasDoneforplot.txt", 
                                   delim = "\t", escape_double = FALSE, 
                                   trim_ws = TRUE)


AllAnovasDoneforplot$CCAA <-  factor(  AllAnovasDoneforplot$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                                            "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                                            "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))

ggplot(  AllAnovasDoneforplot,  aes(x= CCAA, y= Contribution*100, fill= Component))+
  geom_bar(stat= "identity", position="stack") +
  theme_bw()+
  geom_hline(yintercept = 0) +
  labs(x="Autonomous Communities",
       y="Contribution") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1, size=15))

# try again separating effects for poster


AllAnovasDoneforplot$Effect[AllAnovasDoneforplot$Component=="AD"] <- "one factor AD"
AllAnovasDoneforplot$Effect[AllAnovasDoneforplot$Component=="AP"] <- "two factor AP"
AllAnovasDoneforplot$Effect[AllAnovasDoneforplot$Component=="APC"] <- "three factor APC"


AllAnovasDoneforplot$Effect<- factor(AllAnovasDoneforplot$Effect, levels =c("one factor AD","two factor AP","three factor APC"))

# plot anovas 

ggplot(  AllAnovasDoneforplot,  aes(x= CCAA, y= Contribution*100, fill= Effect))+
  geom_bar(stat= "identity", position="stack") +
  theme_bw()+
  geom_hline(yintercept = 0) +
  labs(x="Autonomous Communities",
       y="Contribution") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1, size=12))

# separate drift, age, period, cohort effects por individual plots instead of using apc.frame

###APC FEMALES




Drift1 <- apc.AvgF[["Drift"]]
Drift2 <- apc.AndF[["Drift"]]
Drift3 <- apc.AraF[["Drift"]]
Drift4 <- apc.AstF[["Drift"]]
Drift5 <- apc.BalF[["Drift"]]
Drift6 <- apc.PVF[["Drift"]]
Drift7 <- apc.CanF[["Drift"]]
Drift8 <- apc.CantF[["Drift"]]
Drift9 <- apc.CyLF[["Drift"]]
Drift10 <- apc.CLMF[["Drift"]]
Drift11 <- apc.CatF[["Drift"]]
Drift12 <- apc.ExtF[["Drift"]]
Drift13 <- apc.GalF[["Drift"]]
Drift14 <- apc.LRF[["Drift"]]
Drift15 <- apc.MadF[["Drift"]]
Drift16 <- apc.MurF[["Drift"]]
Drift17 <- apc.NavF[["Drift"]]
Drift18 <- apc.ValF[["Drift"]]


allDrifts <- rbind(Drift1,Drift2,Drift3,Drift4,Drift5,Drift6,
                   Drift7,Drift8,Drift9,Drift10,Drift11,Drift12,Drift13,
                   Drift14,Drift15,Drift16,Drift17,Drift18)

allDrifts <- as.data.frame(allDrifts)

NamesVec <- c(rep("Spain",2),
              rep("Andalusia",2),
              rep("Aragon",2),
              rep("Asturias",2),
              rep("Balearic Islands",2),
              rep("Basque Country",2),
              rep("Canary Islands",2),
              rep("Cantabria",2),
              rep("Castile & Leon",2),
              rep("Castile-La Mancha",2),
              rep("Catalonia",2),
              rep("Extremadura",2),
              rep("Galicia",2),
              rep("La Rioja",2),
              rep("Madrid",2),
              rep("Murcia",2),
              rep("Navarra",2),
              rep("Valencian Community",2))


TypesVec <- c(rep(c("Drift","Age-Drift"),18))


allDrifts$CCAA <- NamesVec

allDrifts$Types <- TypesVec

colnames(allDrifts) <- c("Drift","Lower","Upper","CCAA","Types")

randomvec <- c(rep("random",36))



Driftplot <- data.frame(allDrifts$CCAA)

Driftplot$Drift <- allDrifts$Drift
Driftplot$Lower <- allDrifts$Lower
Driftplot$Upper <- allDrifts$Upper
Driftplot$Types <- allDrifts$Types

colnames(Driftplot) <- c("CCAA","Drift","Lower","Upper","Types")
Driftplot1 <- Driftplot %>% 
  filter(Types=="Drift")

Driftplot1$CCAA <-  factor(Driftplot1$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                      "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                      "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))

Driftplot1$CCAA  <- factor(Driftplot1$CCAA, levels=(levels(rev(Driftplot1$Drift))))


ggplot(Driftplot1,aes(x = Drift, y = reorder(CCAA,Drift))) +
  geom_point(size=1, alpha=0.5)+
  geom_errorbar(aes(xmin=Lower, xmax=Upper), width=1) +
  # scale_y_continuous(limits=rev,name= "Condition")+
  theme_bw()+
  scale_y_discrete(limits=rev)+
  geom_vline(xintercept = 1.030740 ,color = "red",alpha=0.8)+
  labs(# title = "CFLE and LEWC by sex and educational attainment, separately by cause" ,size=0.5,
    x="Drift",
    y="Autonomous Community")

# age effects apc model 


Age1 <- apc.AvgF[["Age"]]
Age2 <- apc.AndF[["Age"]]
Age3 <- apc.AraF[["Age"]]
Age4 <- apc.AstF[["Age"]]
Age5 <- apc.BalF[["Age"]]
Age6 <- apc.PVF[["Age"]]
Age7 <- apc.CanF[["Age"]]
Age8 <- apc.CantF[["Age"]]
Age9 <- apc.CyLF[["Age"]]
Age10 <- apc.CLMF[["Age"]]
Age11 <- apc.CatF[["Age"]]
Age12 <- apc.ExtF[["Age"]]
Age13 <- apc.GalF[["Age"]]
Age14 <- apc.LRF[["Age"]]
Age15 <- apc.MadF[["Age"]]
Age16 <- apc.MurF[["Age"]]
Age17 <- apc.NavF[["Age"]]
Age18 <- apc.ValF[["Age"]]


AllAge <- rbind(Age1,Age2,Age3,Age4,Age5,Age6,Age7,Age8,Age9,Age10,Age11,Age12,Age13,Age14,Age15,Age16,Age17,Age18)

AllAge <- as.data.frame(AllAge)

NamesVec <- c(rep("Spain",9),
              rep("Andalusia",9),
              rep("Aragon",9),
              rep("Asturias",9),
              rep("Balearic Islands",9),
              rep("Basque Country",9),
              rep("Canary Islands",9),
              rep("Cantabria",9),
              rep("Castile & Leon",9),
              rep("Castile-La Mancha",9),
              rep("Catalonia",9),
              rep("Extremadura",9),
              rep("Galicia",9),
              rep("La Rioja",9),
              rep("Madrid",9),
              rep("Murcia",9),
              rep("Navarra",9),
              rep("Valencian Community",9))

AllAge$CCAA <- NamesVec

colnames(AllAge) <- c("Age","Rate","Lower","Upper","CCAA")



AllAge$CCAA <-  factor(AllAge$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                              "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                              "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))


ggplot(AllAge,aes(x = Age, y = Rate)) +
  geom_line(size=1, alpha=0.5)+
  geom_ribbon(aes(ymin=Lower, ymax=Upper), linetype=2, alpha=0.5)+
  # geom_errorbar(aes(ymin=Lower, ymax=Upper), width=0.4) +
  theme_bw()+
  xlim(40,90)+
  # geom_vline(xintercept = 50,color = "green",alpha=0.8)+
  # geom_vline(xintercept = 65,color = "black",alpha=0.8)+
  # geom_vline(xintercept = 83,color = "blue",alpha=0.8)+
  scale_y_log10()+
  scale_x_continuous(breaks = seq(from = 40, to = 85, by = 5)) +
  labs(# title = "Age effects by autonomous region" ,size=1,
    x="Age",
    y="Death Rate")+
  facet_wrap(~CCAA, ncol=3)

#  period effects apc model


Per1 <- apc.AvgF[["Per"]]
Per2 <- apc.AndF[["Per"]]
Per3 <- apc.AraF[["Per"]]
Per4 <- apc.AstF[["Per"]]
Per5 <- apc.BalF[["Per"]]
Per6 <- apc.PVF[["Per"]]
Per7 <- apc.CanF[["Per"]]
Per8 <- apc.CantF[["Per"]]
Per9 <- apc.CyLF[["Per"]]
Per10 <- apc.CLMF[["Per"]]
Per11 <- apc.CatF[["Per"]]
Per12 <- apc.ExtF[["Per"]]
Per13 <- apc.GalF[["Per"]]
Per14 <- apc.LRF[["Per"]]
Per15 <- apc.MadF[["Per"]]
Per16 <- apc.MurF[["Per"]]
Per17 <- apc.NavF[["Per"]]
Per18 <- apc.ValF[["Per"]]


AllPer <- rbind(Per1,Per2,Per3,Per4,Per5,Per6,Per7,Per8,Per9,Per10,Per11,Per12,Per13,Per14,Per15,Per16,Per17,Per18)

AllPer <- as.data.frame(AllPer)

NamesVec <- c(rep("Spain",8),
              rep("Andalusia",8),
              rep("Aragon",8),
              rep("Asturias",8),
              rep("Balearic Islands",8),
              rep("Basque Country",8),
              rep("Canary Islands",8),
              rep("Cantabria",8),
              rep("Castile & Leon",8),
              rep("Castile-La Mancha",8),
              rep("Catalonia",8),
              rep("Extremadura",8),
              rep("Galicia",8),
              rep("La Rioja",8),
              rep("Madrid",8),
              rep("Murcia",8),
              rep("Navarra",8),
              rep("Valencian Community",8))

AllPer$CCAA <- NamesVec

colnames(AllPer) <- c("Period","Risk","Lower","Upper","CCAA")



AllPer$CCAA <-  factor(AllPer$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                              "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                              "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))

ggplot(AllPer,aes(x = Period, y = Risk)) +
  # geom_rect(aes(xmin=2005, xmax=2018, ymin=-Inf, ymax=Inf),alpha=0.01)+
  geom_line(size=1, alpha=0.5)+
  geom_ribbon(aes(ymin=Lower, ymax=Upper), linetype=2, alpha=0.5)+
  # geom_errorbar(aes(ymin=Lower, ymax=Upper), width=0.4) +
  theme_bw()+
  xlim(1980,2020)+
  geom_hline(yintercept = 1,color = "red")+
  # geom_vline(xintercept = 1990,color = "green")+
  # geom_vline(xintercept = 2005,color = "black")+
  # geom_vline(xintercept = 2018,color = "blue")+
  scale_x_continuous(breaks = seq(from = 1980, to = 2020, by = 5)) +
  labs(#title = "Period effects by autonomous region" ,size=1,
    x="Period",
    y="Risk-Ratio")+
  facet_wrap(~CCAA, ncol=3)

# cohort apc model 


Coh1 <- apc.AvgF[["Coh"]]
Coh2 <- apc.AndF[["Coh"]]
Coh3 <- apc.AraF[["Coh"]]
Coh4 <- apc.AstF[["Coh"]]
Coh5 <- apc.BalF[["Coh"]]
Coh6 <- apc.PVF[["Coh"]]
Coh7 <- apc.CanF[["Coh"]]
Coh8 <- apc.CantF[["Coh"]]
Coh9 <- apc.CyLF[["Coh"]]
Coh10 <- apc.CLMF[["Coh"]]
Coh11 <- apc.CatF[["Coh"]]
Coh12 <- apc.ExtF[["Coh"]]
Coh13 <- apc.GalF[["Coh"]]
Coh14 <- apc.LRF[["Coh"]]
Coh15 <- apc.MadF[["Coh"]]
Coh16 <- apc.MurF[["Coh"]]
Coh17 <- apc.NavF[["Coh"]]
Coh18 <- apc.ValF[["Coh"]]


AllCoh <- rbind(Coh1,Coh2,Coh3,Coh4,Coh5,Coh6,Coh7,Coh8,Coh9,Coh10,Coh11,Coh12,Coh13,Coh14,Coh15,Coh16,Coh17,Coh18)

AllCoh <- as.data.frame(AllCoh)

NamesVec <- c(rep("Spain",16),
              rep("Andalusia",16),
              rep("Aragon",16),
              rep("Asturias",16),
              rep("Balearic Islands",16),
              rep("Basque Country",16),
              rep("Canary Islands",16),
              rep("Cantabria",16),
              rep("Castile & Leon",16),
              rep("Castile-La Mancha",16),
              rep("Catalonia",16),
              rep("Extremadura",16),
              rep("Galicia",16),
              rep("La Rioja",16),
              rep("Madrid",16),
              rep("Murcia",16),
              rep("Navarra",16),
              rep("Valencian Community",16))

AllCoh$CCAA <- NamesVec

colnames(AllCoh) <- c("Cohort","Risk","Lower","Upper","CCAA")



AllCoh$CCAA <-  factor(AllCoh$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                              "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                              "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))




ggplot(AllCoh,aes(x = Cohort, y = Risk)) +
  # geom_rect(aes(xmin=1952.5, xmax=1978, ymin=-Inf, ymax=Inf),alpha=0.01)+
  geom_line(size=1, alpha=0.5)+
  geom_ribbon(aes(ymin=Lower, ymax=Upper), linetype=2, alpha=0.5)+
  # geom_errorbar(aes(ymin=Lower, ymax=Upper), width=0.4) +
  theme_bw()+
  xlim(1900,1980)+
  ylim(0.25,3)+
  geom_hline(yintercept = 1,color = "red")+
  geom_vline(xintercept = 1935,color = "green")+
  geom_vline(xintercept = 1955,color = "blue")+
  # geom_vline(xintercept = 1977.5,color = "blue")+
  scale_x_continuous(breaks = seq(from = 1900, to = 1975, by = 15)) +
  labs(#title = "Cohort effects by autonomous region" ,size=1,
    x="Birth Cohort",
    y="Risk-Ratio")+
  facet_wrap(~CCAA, ncol=3)

# alternative cohort major 


# alternative

# alternative code for ACP   (Cohort Major)


acp.AvgF <- apc.fit( subset( AvgF ),
                     parm = "ACP",
                     ref.c =  1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.AndF <- apc.fit( subset( AndF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.AraF <- apc.fit( subset( AraF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.AstF <- apc.fit( subset( AstF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.BalF <- apc.fit( subset( BalF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.PVF <- apc.fit( subset( PVF ),
                    parm = "ACP",
                    ref.c = 1935,
                    scale=100000,
                    npar=c(A=5, P=5, C=5))


acp.CanF <- apc.fit( subset( CanF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.CantF <- apc.fit( subset( CantF ),
                      parm = "ACP",
                      ref.c = 1935,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

acp.CyLF <- apc.fit( subset( CyLF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.CLMF <- apc.fit( subset( CLMF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.CatF <- apc.fit( subset( CatF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.ExtF <- apc.fit( subset( ExtF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.GalF <- apc.fit( subset( GalF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.LRF <- apc.fit( subset( LRF ),
                    parm = "ACP",
                    ref.c = 1935,
                    scale=100000,
                    npar=c(A=5, P=5, C=5))

acp.MadF <- apc.fit( subset( MadF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.MurF <- apc.fit( subset( MurF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

acp.NavF <- apc.fit( subset( NavF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))


acp.ValF <- apc.fit( subset( ValF ),
                     parm = "ACP",
                     ref.c = 1935,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))




###ANALYSIS OF DEVIANCE for Cohort (label with C at the end)

anova1C <- acp.AvgF[["Anova"]]
anova2C <- acp.AndF[["Anova"]]
anova3C <- acp.AraF[["Anova"]]
anova4C <- acp.AstF[["Anova"]]
anova5C <- acp.BalF[["Anova"]]
anova6C <- acp.PVF[["Anova"]]
anova7C <- acp.CanF[["Anova"]]
anova8C <- acp.CantF[["Anova"]]
anova9C <- acp.CyLF[["Anova"]]
anova10C <- acp.CLMF[["Anova"]]
anova11C <- acp.CatF[["Anova"]]
anova12C <- acp.ExtF[["Anova"]]
anova13C <- acp.GalF[["Anova"]]
anova14C <- acp.LRF[["Anova"]]
anova15C <- acp.MadF[["Anova"]]
anova16C <- acp.MurF[["Anova"]]
anova17C <- acp.NavF[["Anova"]]
anova18C <- acp.ValF[["Anova"]]


allanovasC <- rbind(anova1C,anova2C,anova3C,anova4C,anova5C,anova6C,
                    anova7C,anova8C,anova9C,anova10C,anova11C,anova12C,anova13C,
                    anova14C,anova15C,anova16C,anova17C,anova18C)


NamesVecC <- c(rep("Spain",6),
               rep("Andalusia",6),
               rep("Aragon",6),
               rep("Asturias",6),
               rep("Balearic Islands",6),
               rep("Basque Country",6),
               rep("Canary Islands",6),
               rep("Cantabria",6),
               rep("Castile & Leon",6),
               rep("Castile-La Mancha",6),
               rep("Catalonia",6),
               rep("Extremadura",6),
               rep("Galicia",6),
               rep("La Rioja",6),
               rep("Madrid",6),
               rep("Murcia",6),
               rep("Navarra",6),
               rep("Valencian Community",6))

allanovasC$CCAA <- NamesVecC

allanovasC$`Test df.`[is.na(allanovasC$`Test df.`)] <- 3

allanovasC2 <- allanovasC %>% 
  filter(`Test df.` !="1",
         Model != "Age-Cohort") %>% 
  group_by(CCAA)

allanovasC2$SumAgeMod <- c(rep(allanovasC2$`Mod. dev.`[1],4),
                           rep(allanovasC2$`Mod. dev.`[5],4),
                           rep(allanovasC2$`Mod. dev.`[9],4),
                           rep(allanovasC2$`Mod. dev.`[13],4),
                           rep(allanovasC2$`Mod. dev.`[17],4),
                           rep(allanovasC2$`Mod. dev.`[21],4),
                           rep(allanovasC2$`Mod. dev.`[25],4),
                           rep(allanovasC2$`Mod. dev.`[29],4),
                           rep(allanovasC2$`Mod. dev.`[33],4),
                           rep(allanovasC2$`Mod. dev.`[37],4),
                           rep(allanovasC2$`Mod. dev.`[41],4),
                           rep(allanovasC2$`Mod. dev.`[45],4),
                           rep(allanovasC2$`Mod. dev.`[49],4),
                           rep(allanovasC2$`Mod. dev.`[53],4),
                           rep(allanovasC2$`Mod. dev.`[57],4),
                           rep(allanovasC2$`Mod. dev.`[61],4),
                           rep(allanovasC2$`Mod. dev.`[65],4),
                           rep(allanovasC2$`Mod. dev.`[69],4))

allanovasC2 <- allanovasC2 %>%
  mutate(DifAgeMod= SumAgeMod -`Mod. dev.`) %>% 
  group_by(CCAA) %>% 
  filter(DifAgeMod >0)


allanovasC2$AllDifMod <- c(rep(allanovasC2$DifAgeMod[1],3),
                           rep(allanovasC2$DifAgeMod[4],3),
                           rep(allanovasC2$DifAgeMod[7],3),
                           rep(allanovasC2$DifAgeMod[10],3),
                           rep(allanovasC2$DifAgeMod[13],3),
                           rep(allanovasC2$DifAgeMod[16],3),
                           rep(allanovasC2$DifAgeMod[19],3),
                           rep(allanovasC2$DifAgeMod[22],3),
                           rep(allanovasC2$DifAgeMod[25],3),
                           rep(allanovasC2$DifAgeMod[28],3),
                           rep(allanovasC2$DifAgeMod[31],3),
                           rep(allanovasC2$DifAgeMod[34],3),
                           rep(allanovasC2$DifAgeMod[37],3),
                           rep(allanovasC2$DifAgeMod[40],3),
                           rep(allanovasC2$DifAgeMod[43],3),
                           rep(allanovasC2$DifAgeMod[46],3),
                           rep(allanovasC2$DifAgeMod[49],3),
                           rep(allanovasC2$DifAgeMod[52],3))

library(readr)




Age1C <- acp.AvgF[["Age"]]
Age2C <- acp.AndF[["Age"]]
Age3C <- acp.AraF[["Age"]]
Age4C <- acp.AstF[["Age"]]
Age5C <- acp.BalF[["Age"]]
Age6C <- acp.PVF[["Age"]]
Age7C <- acp.CanF[["Age"]]
Age8C <- acp.CantF[["Age"]]
Age9C <- acp.CyLF[["Age"]]
Age10C <- acp.CLMF[["Age"]]
Age11C <- acp.CatF[["Age"]]
Age12C <- acp.ExtF[["Age"]]
Age13C <- acp.GalF[["Age"]]
Age14C <- acp.LRF[["Age"]]
Age15C <- acp.MadF[["Age"]]
Age16C <- acp.MurF[["Age"]]
Age17C <- acp.NavF[["Age"]]
Age18C <- acp.ValF[["Age"]]


AllAgeC <- rbind(Age1C,Age2C,Age3C,Age4C,Age5C,Age6C,Age7C,Age8C,Age9C,Age10C,Age11C,Age12C,Age13C,Age14C,Age15C,Age16C,Age17C,Age18C)

AllAgeC <- as.data.frame(AllAgeC)

NamesVecC <- c(rep("Spain",9),
               rep("Andalusia",9),
               rep("Aragon",9),
               rep("Asturias",9),
               rep("Balearic Islands",9),
               rep("Basque Country",9),
               rep("Canary Islands",9),
               rep("Cantabria",9),
               rep("Castile & Leon",9),
               rep("Castile-La Mancha",9),
               rep("Catalonia",9),
               rep("Extremadura",9),
               rep("Galicia",9),
               rep("La Rioja",9),
               rep("Madrid",9),
               rep("Murcia",9),
               rep("Navarra",9),
               rep("Valencian Community",9))

AllAgeC$CCAA <- NamesVecC

colnames(AllAgeC) <- c("Age","Rate","Lower","Upper","CCAA")



AllAgeC$CCAA <-  factor(AllAgeC$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))


ggplot(AllAgeC,aes(x = Age, y = Rate)) +
  geom_line(size=1, alpha=0.5)+
  geom_ribbon(aes(ymin=Lower, ymax=Upper), linetype=2, alpha=0.5)+
  # geom_errorbar(aes(ymin=Lower, ymax=Upper), width=0.4) +
  theme_bw()+
  xlim(40,90)+
  # geom_vline(xintercept = 50,color = "green",alpha=0.8)+
  # geom_vline(xintercept = 65,color = "black",alpha=0.8)+
  # geom_vline(xintercept = 83,color = "blue",alpha=0.8)+
  scale_y_log10()+
  scale_x_continuous(breaks = seq(from = 40, to = 85, by = 5)) +
  labs(# title = "Age effects by autonomous region" ,size=1,
    x="Age",
    y="Log Death Rate")+
  facet_wrap(~CCAA, ncol=3)



Per1C <- acp.AvgF[["Per"]]
Per2C <- acp.AndF[["Per"]]
Per3C <- acp.AraF[["Per"]]
Per4C <- acp.AstF[["Per"]]
Per5C <- acp.BalF[["Per"]]
Per6C <- acp.PVF[["Per"]]
Per7C <- acp.CanF[["Per"]]
Per8C <- acp.CantF[["Per"]]
Per9C <- acp.CyLF[["Per"]]
Per10C <- acp.CLMF[["Per"]]
Per11C <- acp.CatF[["Per"]]
Per12C <- acp.ExtF[["Per"]]
Per13C <- acp.GalF[["Per"]]
Per14C <- acp.LRF[["Per"]]
Per15C <- acp.MadF[["Per"]]
Per16C <- acp.MurF[["Per"]]
Per17C <- acp.NavF[["Per"]]
Per18C <- acp.ValF[["Per"]]


AllPerC <- rbind(Per1C,Per2C,Per3C,Per4C,Per5C,Per6C,Per7C,Per8C,Per9C,Per10C,Per11C,Per12C,Per13C,Per14C,Per15C,Per16C,Per17C,Per18C)

AllPerC <- as.data.frame(AllPerC)

NamesVecC <- c(rep("Spain",8),
               rep("Andalusia",8),
               rep("Aragon",8),
               rep("Asturias",8),
               rep("Balearic Islands",8),
               rep("Basque Country",8),
               rep("Canary Islands",8),
               rep("Cantabria",8),
               rep("Castile & Leon",8),
               rep("Castile-La Mancha",8),
               rep("Catalonia",8),
               rep("Extremadura",8),
               rep("Galicia",8),
               rep("La Rioja",8),
               rep("Madrid",8),
               rep("Murcia",8),
               rep("Navarra",8),
               rep("Valencian Community",8))

AllPerC$CCAA <- NamesVecC

colnames(AllPerC) <- c("Period","Risk","Lower","Upper","CCAA")



AllPerC$CCAA <-  factor(AllPerC$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))

ggplot(AllPerC,aes(x = Period, y = Risk)) +
  # geom_rect(aes(xmin=2005, xmax=2018, ymin=-Inf, ymax=Inf),alpha=0.01)+
  geom_line(size=1, alpha=0.5)+
  geom_ribbon(aes(ymin=Lower, ymax=Upper), linetype=2, alpha=0.5)+
  # geom_errorbar(aes(ymin=Lower, ymax=Upper), width=0.4) +
  theme_bw()+
  xlim(1980,2020)+
  geom_hline(yintercept = 1,color = "red")+
  # geom_vline(xintercept = 1990,color = "green")+
  # geom_vline(xintercept = 2005,color = "black")+
  # geom_vline(xintercept = 2018,color = "blue")+
  scale_x_continuous(breaks = seq(from = 1980, to = 2020, by = 5)) +
  labs(#title = "Period effects by autonomous region" ,size=1,
    x="Period",
    y="Risk-Ratio")+
  facet_wrap(~CCAA, ncol=3)



Coh1C <- acp.AvgF[["Coh"]]
Coh2C <- acp.AndF[["Coh"]]
Coh3C <- acp.AraF[["Coh"]]
Coh4C <- acp.AstF[["Coh"]]
Coh5C <- acp.BalF[["Coh"]]
Coh6C <- acp.PVF[["Coh"]]
Coh7C <- acp.CanF[["Coh"]]
Coh8C <- acp.CantF[["Coh"]]
Coh9C <- acp.CyLF[["Coh"]]
Coh10C <- acp.CLMF[["Coh"]]
Coh11C <- acp.CatF[["Coh"]]
Coh12C <- acp.ExtF[["Coh"]]
Coh13C <- acp.GalF[["Coh"]]
Coh14C <- acp.LRF[["Coh"]]
Coh15C <- acp.MadF[["Coh"]]
Coh16C <- acp.MurF[["Coh"]]
Coh17C <- acp.NavF[["Coh"]]
Coh18C <- acp.ValF[["Coh"]]


AllCohC <- rbind(Coh1C,Coh2C,Coh3C,Coh4C,Coh5C,Coh6C,Coh7C,Coh8C,Coh9C,Coh10C,Coh11C,Coh12C,Coh13C,Coh14C,Coh15C,Coh16C,Coh17C,Coh18C)

AllCohC <- as.data.frame(AllCohC)

NamesVecC <- c(rep("Spain",16),
               rep("Andalusia",16),
               rep("Aragon",16),
               rep("Asturias",16),
               rep("Balearic Islands",16),
               rep("Basque Country",16),
               rep("Canary Islands",16),
               rep("Cantabria",16),
               rep("Castile & Leon",16),
               rep("Castile-La Mancha",16),
               rep("Catalonia",16),
               rep("Extremadura",16),
               rep("Galicia",16),
               rep("La Rioja",16),
               rep("Madrid",16),
               rep("Murcia",16),
               rep("Navarra",16),
               rep("Valencian Community",16))

AllCohC$CCAA <- NamesVecC

colnames(AllCohC) <- c("Cohort","Risk","Lower","Upper","CCAA")



AllCohC$CCAA <-  factor(AllCohC$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))




ggplot(AllCohC,aes(x = Cohort, y = Risk)) +
  # geom_rect(aes(xmin=1952.5, xmax=1978, ymin=-Inf, ymax=Inf),alpha=0.01)+
  geom_line(size=1, alpha=0.5)+
  geom_ribbon(aes(ymin=Lower, ymax=Upper), linetype=2, alpha=0.5)+
  # geom_errorbar(aes(ymin=Lower, ymax=Upper), width=0.4) +
  theme_bw()+
  xlim(1900,1980)+
  geom_hline(yintercept = 1,color = "red")+
  geom_vline(xintercept = 1935,color = "green")+
  geom_vline(xintercept = 1955,color = "blue")+
  # geom_vline(xintercept = 1977.5,color = "blue")+
  scale_x_continuous(breaks = seq(from = 1900, to = 1975, by = 15)) +
  labs(#title = "Cohort effects by autonomous region" ,size=1,
    x="Birth Cohort",
    y="Risk-Ratio")+
  facet_wrap(~CCAA, ncol=3)




