# extra smoothing for lexis surface




apc.AvgF1 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 1982.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF2 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 1987.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF3 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 1992.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF4 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 1997.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF5 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 2002.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF6 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 2007.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF7 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 2012.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.AvgF8 <- apc.fit( subset( AvgF ),
                     parm = "APC",
                     ref.p = 2017.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))


AvgSmoothRate <- rbind(apc.AvgF1[["Age"]],
                       apc.AvgF2[["Age"]],
                       apc.AvgF3[["Age"]],
                       apc.AvgF4[["Age"]],
                       apc.AvgF5[["Age"]],
                       apc.AvgF6[["Age"]],
                       apc.AvgF7[["Age"]],
                       apc.AvgF8[["Age"]])


apc.AndF1 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF2 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF3 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF4 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF5 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF6 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF7 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AndF8 <- apc.fit( subset( AndF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


AndSmoothRate <- rbind(apc.AndF1[["Age"]],
                       apc.AndF2[["Age"]],
                       apc.AndF3[["Age"]],
                       apc.AndF4[["Age"]],
                       apc.AndF5[["Age"]],
                       apc.AndF6[["Age"]],
                       apc.AndF7[["Age"]],
                       apc.AndF8[["Age"]])


AllSmoothRate <- as.data.frame(AllSmoothRate)







apc.AraF1 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF2 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF3 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF4 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF5 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF6 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF7 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AraF8 <- apc.fit( subset( AraF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


AraSmoothRate <- rbind(apc.AraF1[["Age"]],
                       apc.AraF2[["Age"]],
                       apc.AraF3[["Age"]],
                       apc.AraF4[["Age"]],
                       apc.AraF5[["Age"]],
                       apc.AraF6[["Age"]],
                       apc.AraF7[["Age"]],
                       apc.AraF8[["Age"]])






apc.AstF1 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF2 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF3 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF4 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF5 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF6 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF7 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.AstF8 <- apc.fit( subset( AstF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


AstSmoothRate <- rbind(apc.AstF1[["Age"]],
                       apc.AstF2[["Age"]],
                       apc.AstF3[["Age"]],
                       apc.AstF4[["Age"]],
                       apc.AstF5[["Age"]],
                       apc.AstF6[["Age"]],
                       apc.AstF7[["Age"]],
                       apc.AstF8[["Age"]])





apc.BalF1 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF2 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF3 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF4 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF5 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF6 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF7 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.BalF8 <- apc.fit( subset( BalF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


BalSmoothRate <- rbind(apc.BalF1[["Age"]],
                       apc.BalF2[["Age"]],
                       apc.BalF3[["Age"]],
                       apc.BalF4[["Age"]],
                       apc.BalF5[["Age"]],
                       apc.BalF6[["Age"]],
                       apc.BalF7[["Age"]],
                       apc.BalF8[["Age"]])





apc.PVF1 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1982.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF2 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1987.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF3 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1992.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF4 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 1997.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF5 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 2002.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF6 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 2007.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF7 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 2012.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.PVF8 <- apc.fit( subset( PVF ),
                     parm = "APC",
                     ref.p = 2017.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))


PVSmoothRate <- rbind(apc.PVF1[["Age"]],
                      apc.PVF2[["Age"]],
                      apc.PVF3[["Age"]],
                      apc.PVF4[["Age"]],
                      apc.PVF5[["Age"]],
                      apc.PVF6[["Age"]],
                      apc.PVF7[["Age"]],
                      apc.PVF8[["Age"]])





apc.CanF1 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF2 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF3 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF4 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF5 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF6 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF7 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CanF8 <- apc.fit( subset( CanF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


CanSmoothRate <- rbind(apc.CanF1[["Age"]],
                       apc.CanF2[["Age"]],
                       apc.CanF3[["Age"]],
                       apc.CanF4[["Age"]],
                       apc.CanF5[["Age"]],
                       apc.CanF6[["Age"]],
                       apc.CanF7[["Age"]],
                       apc.CanF8[["Age"]])





apc.CantF1 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1982.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF2 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1987.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF3 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1992.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF4 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 1997.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF5 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 2002.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF6 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 2007.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF7 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 2012.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))

apc.CantF8 <- apc.fit( subset( CantF ),
                       parm = "APC",
                       ref.p = 2017.5,
                       scale=100000,
                       npar=c(A=5, P=5, C=5))


CantSmoothRate <- rbind(apc.CantF1[["Age"]],
                        apc.CantF2[["Age"]],
                        apc.CantF3[["Age"]],
                        apc.CantF4[["Age"]],
                        apc.CantF5[["Age"]],
                        apc.CantF6[["Age"]],
                        apc.CantF7[["Age"]],
                        apc.CantF8[["Age"]])





apc.CyLF1 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF2 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF3 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF4 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF5 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF6 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF7 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CyLF8 <- apc.fit( subset( CyLF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


CyLSmoothRate <- rbind(apc.CyLF1[["Age"]],
                       apc.CyLF2[["Age"]],
                       apc.CyLF3[["Age"]],
                       apc.CyLF4[["Age"]],
                       apc.CyLF5[["Age"]],
                       apc.CyLF6[["Age"]],
                       apc.CyLF7[["Age"]],
                       apc.CyLF8[["Age"]])




apc.CLMF1 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF2 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF3 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF4 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF5 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF6 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF7 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CLMF8 <- apc.fit( subset( CLMF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


CLMSmoothRate <- rbind(apc.CLMF1[["Age"]],
                       apc.CLMF2[["Age"]],
                       apc.CLMF3[["Age"]],
                       apc.CLMF4[["Age"]],
                       apc.CLMF5[["Age"]],
                       apc.CLMF6[["Age"]],
                       apc.CLMF7[["Age"]],
                       apc.CLMF8[["Age"]])





apc.CatF1 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF2 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF3 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF4 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF5 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF6 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF7 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.CatF8 <- apc.fit( subset( CatF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


CatSmoothRate <- rbind(apc.CatF1[["Age"]],
                       apc.CatF2[["Age"]],
                       apc.CatF3[["Age"]],
                       apc.CatF4[["Age"]],
                       apc.CatF5[["Age"]],
                       apc.CatF6[["Age"]],
                       apc.CatF7[["Age"]],
                       apc.CatF8[["Age"]])





apc.ExtF1 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF2 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF3 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF4 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF5 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF6 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF7 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ExtF8 <- apc.fit( subset( ExtF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


ExtSmoothRate <- rbind(apc.ExtF1[["Age"]],
                       apc.ExtF2[["Age"]],
                       apc.ExtF3[["Age"]],
                       apc.ExtF4[["Age"]],
                       apc.ExtF5[["Age"]],
                       apc.ExtF6[["Age"]],
                       apc.ExtF7[["Age"]],
                       apc.ExtF8[["Age"]])




apc.GalF1 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF2 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF3 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF4 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF5 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF6 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF7 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.GalF8 <- apc.fit( subset( GalF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


GalSmoothRate <- rbind(apc.GalF1[["Age"]],
                       apc.GalF2[["Age"]],
                       apc.GalF3[["Age"]],
                       apc.GalF4[["Age"]],
                       apc.GalF5[["Age"]],
                       apc.GalF6[["Age"]],
                       apc.GalF7[["Age"]],
                       apc.GalF8[["Age"]])




apc.LRF1 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1982.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF2 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1987.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF3 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1992.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF4 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 1997.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF5 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 2002.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF6 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 2007.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF7 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 2012.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))

apc.LRF8 <- apc.fit( subset( LRF ),
                     parm = "APC",
                     ref.p = 2017.5,
                     scale=100000,
                     npar=c(A=5, P=5, C=5))


LRSmoothRate <- rbind(apc.LRF1[["Age"]],
                      apc.LRF2[["Age"]],
                      apc.LRF3[["Age"]],
                      apc.LRF4[["Age"]],
                      apc.LRF5[["Age"]],
                      apc.LRF6[["Age"]],
                      apc.LRF7[["Age"]],
                      apc.LRF8[["Age"]])




apc.MadF1 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF2 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF3 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF4 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF5 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF6 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF7 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MadF8 <- apc.fit( subset( MadF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


MadSmoothRate <- rbind(apc.MadF1[["Age"]],
                       apc.MadF2[["Age"]],
                       apc.MadF3[["Age"]],
                       apc.MadF4[["Age"]],
                       apc.MadF5[["Age"]],
                       apc.MadF6[["Age"]],
                       apc.MadF7[["Age"]],
                       apc.MadF8[["Age"]])




apc.MurF1 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF2 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF3 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF4 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF5 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF6 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF7 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.MurF8 <- apc.fit( subset( MurF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


MurSmoothRate <- rbind(apc.MurF1[["Age"]],
                       apc.MurF2[["Age"]],
                       apc.MurF3[["Age"]],
                       apc.MurF4[["Age"]],
                       apc.MurF5[["Age"]],
                       apc.MurF6[["Age"]],
                       apc.MurF7[["Age"]],
                       apc.MurF8[["Age"]])





apc.NavF1 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF2 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF3 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF4 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF5 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF6 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF7 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.NavF8 <- apc.fit( subset( NavF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


NavSmoothRate <- rbind(apc.NavF1[["Age"]],
                       apc.NavF2[["Age"]],
                       apc.NavF3[["Age"]],
                       apc.NavF4[["Age"]],
                       apc.NavF5[["Age"]],
                       apc.NavF6[["Age"]],
                       apc.NavF7[["Age"]],
                       apc.NavF8[["Age"]])





apc.ValF1 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1982.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF2 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1987.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF3 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1992.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF4 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 1997.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF5 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 2002.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF6 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 2007.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF7 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 2012.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))

apc.ValF8 <- apc.fit( subset( ValF ),
                      parm = "APC",
                      ref.p = 2017.5,
                      scale=100000,
                      npar=c(A=5, P=5, C=5))


ValSmoothRate <- rbind(apc.ValF1[["Age"]],
                       apc.ValF2[["Age"]],
                       apc.ValF3[["Age"]],
                       apc.ValF4[["Age"]],
                       apc.ValF5[["Age"]],
                       apc.ValF6[["Age"]],
                       apc.ValF7[["Age"]],
                       apc.ValF8[["Age"]])



CombinedSmoothRate <- rbind(AvgSmoothRate,
                            AndSmoothRate,
                            AraSmoothRate,
                            AstSmoothRate,
                            BalSmoothRate,
                            PVSmoothRate,
                            CanSmoothRate,
                            CantSmoothRate,
                            CyLSmoothRate,
                            CLMSmoothRate,
                            CatSmoothRate,
                            ExtSmoothRate,
                            GalSmoothRate,
                            LRSmoothRate,
                            MadSmoothRate,
                            MurSmoothRate,
                            NavSmoothRate,
                            ValSmoothRate)



CombinedSmoothRate <- as.data.frame(CombinedSmoothRate)


CombinedSmoothRate$Period <- rep(c(rep(1982.5,9),
            rep(1987.5,9),
            rep(1992.5,9),
            rep(1997.5,9),
            rep(2002.5,9),
            rep(2007.5,9),
            rep(2012.5,9),
            rep(2017.5,9)),18)


CombinedSmoothRate$CCAA <- c(rep("Spain",72),
              rep("Andalusia",72),
              rep("Aragon",72),
              rep("Asturias",72),
              rep("Balearic Islands",72),
              rep("Basque Country",72),
              rep("Canary Islands",72),
              rep("Cantabria",72),
              rep("Castile & Leon",72),
              rep("Castile-La Mancha",72),
              rep("Catalonia",72),
              rep("Extremadura",72),
              rep("Galicia",72),
              rep("La Rioja",72),
              rep("Madrid",72),
              rep("Murcia",72),
              rep("Navarra",72),
              rep("Valencian Community",72))



CombinedSmoothRate2 <- CombinedSmoothRate %>% 
  group_by(Period,CCAA) %>% 
  mutate(ch = ((Rate / lag(Rate)) - 1) * 100,
         ch2 = Rate/lag(Rate)) %>% 
  ungroup() %>% 
  drop_na()





ggplot(CombinedSmoothRate,aes(x=Period,y=Age,z=log(Rate)))+
  geom_tile(aes(fill=log(Rate)),alpha=1,
            linetype=1) +
   geom_contour(breaks=c(5,15,20,50,70), col = "black", size = .15, alpha = 1)+
   # geom_contour(aes(z = Period-Age),breaks=c(5,15,20,50,75), alpha=1, color="black", size=.3)+ 
   geom_text_contour(aes(z = Period-Age), skip=0, label.placer = label_placement_n(1), stroke = 0.15) +
  scale_fill_viridis(option = "D", discrete = F,  direction = -1)+
  # scale_fill_gradient(low = "yellow", high = "purple") +
  # theme_bw()+
  # scale_y_log10()+
  # scale_x_log10()+
  # scale_colour_manual(values = Rate, limits = c("0","100000"))+
  # scale_fill_manual(limits= c("sienna1","hotpink1"))+
  labs(x="Year"
       ,y="Age",
       fill="Log Death Rate 
       (per 100000)")+
  lexis_shape+
  facet_wrap(~CCAA,ncol = 6)



ggplot(CombinedSmoothRate2,aes(x=Period,y=Age,z=log(ch2)))+
  geom_tile(aes(fill=log(ch2)),alpha=1,
            linetype=1) +
  # geom_contour(breaks=c(0.25,0.5,1,2), col = "black", size = .15, alpha = 1)+
  geom_contour(aes(z = Period-Age),breaks=c(5,15,20,50,75), alpha=1, color="black", size=.3)+ 
  geom_text_contour(aes(z = Period-Age), stroke = 0.15) +
  scale_fill_viridis(option = "D", discrete = F,  direction = -1)+
  # scale_fill_gradient(low = "yellow", high = "purple") +
  # theme_bw()+
  # scale_y_log10()+
  # scale_x_log10()+
  # scale_colour_manual(values = Rate, limits = c("0","100000"))+
  # scale_fill_manual(limits= c("sienna1","hotpink1"))+
  labs(x="Year"
       ,y="Age",
       fill="Log Death Rate 
       (per 100000)")+
  lexis_shape+
  facet_wrap(~CCAA,ncol = 6)





#codeforlexissurfaces and diagram
amin <- 40
amax <- 80
pmin <- 1980
pmax <- 2020

p_lexis <- 
  ggplot()+
  # adding lines for periods
  geom_vline(xintercept = seq(pmin, pmax, 5), 
             linewidth = 0.2, linetype = "dashed", alpha = 0.8, color = "grey30")+
  # adding lines for ages
  geom_hline(yintercept = seq(amin, amax, 5), 
             linewidth = 0.2, linetype = "dashed", alpha = 0.8, color = "grey30")+
  theme_bw()

p_lexis

# lets plot the life of someone who was born in 1960
bt_coh <- 1960

p_lexis+
  geom_segment(aes(x = bt_coh, y = 40, xend = pmax, yend = pmax - bt_coh), 
               colour = "red")

# the age and period scales are different, and there is unnecessary extra space
p_lexis+
  geom_segment(aes(x = bt_coh, y = 40, xend = pmax, yend = pmax - bt_coh), 
               colour = "red")+
  # cutting extra space
  coord_equal(expand = 0)


# a few additional things
p_lexis+
  geom_segment(aes(x = bt_coh, y = 40, xend = pmax, yend = pmax - bt_coh), 
               colour = "red")+
  coord_equal(expand = 0)+
  # adding proper labels to both axis
  scale_x_continuous(breaks = seq(pmin, pmax, 5))+
  scale_y_continuous(breaks = seq(amin, amax, 5))+
  # adding axis titles
  labs(y = "Age", x = "Period")+
  # adding cohorts
  geom_abline(intercept = seq(-pmax, -(pmin-amax), 2.5), slope = 1, 
              linetype = "dashed", color = "grey30", linewidth = .2, alpha = 0.8)

# saving preferences in an object
# tip: we can create a list of customizations and then apply that to the plot
lexis_shape <- 
  list(
    geom_vline(xintercept = seq(pmin, pmax, 10), 
               linewidth = 0.2, linetype = "dashed", 
               alpha = 0.8, color = "grey30"),
    geom_hline(yintercept = seq(amin, amax, 10), 
               linewidth = 0.2, linetype = "dashed", 
               alpha = 0.8, color = "grey30"),
    # adding cohorts
    geom_abline(intercept = seq(-pmax, -(pmin-amax), 10), slope = 1, 
                linetype = "dashed", color = "grey30", 
                linewidth = .2, alpha = 0.8),
    coord_equal(expand = 0),
    # adding proper labels to both axis
    scale_x_continuous(breaks = c(1980,1990,2000,2010)),
    scale_y_continuous(breaks = seq(amin, amax, 10)),
    # adding axis titles
    labs(y = "Age", x = "Period"),
    theme_bw(),
    theme(text= element_text(size=12),
          axis.text.x = element_text(angle = 90, vjust = 0.1, hjust=2))
  )


lexis_shape2 <-  list(
  geom_vline(xintercept = seq(pmin, pmax, 5), 
             linewidth = 0.2, linetype = "dashed", 
             alpha = 0.8, color = "grey30"),
  geom_hline(yintercept = seq(amin, amax, 5), 
             linewidth = 0.2, linetype = "dashed", 
             alpha = 0.8, color = "grey30"),
  # adding cohorts
  geom_abline(intercept = seq(-pmax, -(pmin-amax), 5), slope = 1, 
              linetype = "dashed", color = "grey30", 
              linewidth = .2, alpha = 0.8),
  # coord_equal(expand = 0),
  # adding proper labels to both axis
  scale_x_continuous(breaks = c(1980,1985,1990,1995,2000,2005,2010,2015)),
  scale_y_continuous(breaks = seq(amin, amax, 5)),
  # adding axis titles
  labs(y = "Age", x = "Period"),
  theme_bw(),
  theme(text= element_text(size=12),
        axis.text.x = element_text(angle = 90, vjust = 0.1, hjust=2))+
    theme(legend.position = "none")
)

# lexis plot of rates 

CancerFemales$RateT <- CancerFemales$Rate*100000

ggplot(CancerFemales,aes(x=Period,y=Edad,z=RateT))+
  geom_tile(aes(fill=RateT),alpha=1,
            linetype=1) +
  geom_contour(breaks=c(12.5,25,40), col = "black", size = .15, alpha = 1)+
  geom_contour(aes(z = Cohort), alpha=1, color="black", size=.3)+ 
  geom_text_contour(aes(z = Cohort), stroke = 0.15) +
  scale_fill_viridis(option = "D", discrete = F,  direction = -1)+
  # scale_fill_gradient(low = "yellow", high = "purple") +
  # theme_bw()+
  # scale_y_log10()+
  # scale_x_log10()+
  # scale_colour_manual(values = Rate, limits = c("0","100000"))+
  # scale_fill_manual(limits= c("sienna1","hotpink1"))+
  labs(x="Year"
       ,y="Age",
       fill="Death Rate 
       (per 100000)")+
  lexis_shape+
  facet_wrap(~CCAA2,ncol = 6)



CombinedSmoothRate$CCAA <-  factor(CombinedSmoothRate$CCAA, levels =c("Spain", "Andalusia", "Aragon", "Asturias","Balearic Islands", "Basque Country",
                                                                      "Canary Islands","Cantabria","Castile & Leon","Castile-La Mancha","Catalonia",
                                                                      "Extremadura","Galicia","La Rioja", "Madrid","Murcia","Navarra","Valencian Community"))

metR::geom_text_contour()
library(metR)
librar(viridis)


ggplot(CombinedSmoothRate,aes(x=Period,y=Age,z=log(Rate)))+
  geom_tile(aes(fill=log(Rate)),alpha=1,
            linetype=1) +
  geom_contour(breaks=c(1,1.5,2,2.5,3,3.5,4), col = "black", size = .15, alpha = 1)+
  # geom_contour(aes(z = Period-Age),breaks=c(5,15,20,50,75), alpha=1, color="black", size=.3)+ 
  geom_text_contour(aes(z = Period-Age), skip=0, label.placer = label_placement_n(1), stroke = 0.15) +
  scale_fill_viridis(option = "D", discrete = F,  direction = -1)+
  # scale_fill_gradient(low = "yellow", high = "purple") +
  # theme_bw()+
  # scale_y_log10()+
  # scale_x_log10()+
  # scale_colour_manual(values = Rate, limits = c("0","100000"))+
  # scale_fill_manual(limits= c("sienna1","hotpink1"))+
  labs(x="Year"
       ,y="Age",
       fill="Log Death Rate 
       (per 100000)")+
  lexis_shape+
  facet_wrap(~CCAA,ncol = 6)




