
# trend considering linear effects for test linear models after 1952.5 
LateCoh <- AllCohC %>% 
  select(Risk,CCAA,Cohort) %>% 
  filter(Cohort >1952.5) %>% 
  pivot_wider(names_from=Cohort,values_from=Risk) 


colnames(LateCoh) <- c("CCAA","Coh1955","Coh1960","Coh1965","Coh1970","Coh1975")
LateCoh$AvgVar <- log(LateCoh$Coh1975)-(log(LateCoh$Coh1955))

# in case you want to change relative risk for standardized rates 

# Stand2017 <- SRATEALL %>% 
#   select(Period,Standardizedrate,CCAA) %>% 
#   filter(Period==2017.5) 

MiniLateCoh <- LateCoh %>% 
  select(CCAA,AvgVar)

library(readxl)

EconomicvariablesSpain <-  read_excel("C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/InfoCCAA.xlsx")
prevalencesmoke <- read_delim("C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/smoking females by CCAA.txt", 
                              delim = "\t", escape_double = FALSE, 
                              trim_ws = TRUE)


prevalencesmoke$Total <- prevalencesmoke$Regular + prevalencesmoke$Occasional
prevalencesmoke$Ever <- prevalencesmoke$Total + prevalencesmoke$Ex


prevalencesmoke$CCAA[prevalencesmoke$CCAA=="Total"]<-"Spain"

prevalencesmokeL <- prevalencesmoke %>% 
  pivot_longer (cols=c(2,3,4,6,7),
                names_to = "Type",
                values_to = "Prevalence")

Ex2017 <- prevalencesmokeL %>% 
  filter(Year==2017,Type=="Ex")

RegularSmoke <- prevalencesmokeL %>% 
  filter(Year!=2011,Type=="Regular") %>% 
  pivot_wider(names_from = Year, values_from = Prevalence)


EverSmoke <- prevalencesmokeL %>% 
  filter(Year!=2011,Type=="Ever") %>% 
  pivot_wider(names_from = Year, values_from = Prevalence)


colnames(RegularSmoke) <- c("CCAA","Type","Reg2003","Reg2017")

colnames(EverSmoke) <- c("CCAA","Type","Ever2003","Ever2017")

RegularSmoke$RegDif <- RegularSmoke$Reg2003 - RegularSmoke$Reg2017

EverSmoke$EverDif <- EverSmoke$Ever2003 - EverSmoke$Ever2017

RegularSmoke <-   RegularSmoke %>% 
  select(CCAA,RegDif)
EverSmoke <-   EverSmoke %>% 
  select(CCAA,EverDif)

AssociationData <- left_join(MiniLateCoh,EconomicvariablesSpain, by="CCAA")
AssociationData <- left_join(AssociationData,Ex2017, by="CCAA")
AssociationData <- left_join(AssociationData,RegularSmoke, by="CCAA")
AssociationData <- left_join(AssociationData,EverSmoke, by="CCAA")
AssociationData <- left_join(AssociationData,Stand2017, by="CCAA")
# # 
# write.table(AssociationData,"C:/Users/obramajo/Desktop/Tesis Bramajo/Cancer Project/Table2AforappendixCancerProject.xlsx",sep="//")

par(mfrow=c(2,4))

log(AssociationData$GDP2017) 


options(scipen=999)

model1 <- lm(AvgVar ~ Expenditure2017, data=AssociationData)
summary(model1)

model2 <- lm(AvgVar ~ GDP2017, data=AssociationData)
summary(model2)

model3 <- lm(AvgVar ~ log(GDP2017), data=AssociationData)
summary(model3)

model4 <- lm(AvgVar ~ Prevalence, data=AssociationData)
summary(model4)

model5 <- lm(AvgVar ~ RegDif, data=AssociationData)
summary(model5)

model6 <- lm(AvgVar ~ HighEducation, data=AssociationData)
summary(model6)

model7 <- lm(AvgVar ~ DifExpRel, data=AssociationData)
summary(model7)

model8 <- lm(AvgVar ~ DifExpAbs, data=AssociationData)
summary(model8)

model9 <- lm(AvgVar ~  EverDif, data=AssociationData)
summary(model9)

# other unused models but i don't think they work given the number of observations 

model10 <- lm(AvgVar ~  GDP2017*RegDif, data=AssociationData)
summary(model10)

model11 <- lm(AvgVar ~  HighEducation*RegDif, data=AssociationData)
summary(model11)

model12 <- lm(AvgVar ~ RegDif + HighEducation + GDP2017, data=AssociationData)
summary(model12)
plot(model12)

model13 <- lm(AvgVar ~ HighEducation + GDP2017, data=AssociationData)
summary(model13)


